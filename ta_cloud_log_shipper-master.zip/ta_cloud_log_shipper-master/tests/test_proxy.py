import pytest
from src.actions.configure_proxy import configure_proxy, pre_write_checks
import os
import shutil
from src.constants import CONFIG_DIR

class SimulateUserInputs:

    def __init__(self, inputs):
        self.inputs = inputs
        self.count = 0

    def get_input(self):
        self.count += 1
        return self.inputs[self.count - 1]


conf_prox = [
    'y',
    'https',
    'localhost',
    '3128',
    'y',
    'root',
    'admin',
    'y',
    'n'
]


@pytest.mark.parametrize('inp_val', [(conf_prox)])
def test_configure_proxy(monkeypatch, inp_val):
    simulator = SimulateUserInputs(inp_val)

    def mock_get_input(*args):
        return simulator.get_input()

    result = []

    def mock_env(*args):
        result.append(args[0][0]['path'])

    def mock_mkdir(*args):
        print(args)
    
    import src
    monkeypatch.setattr('builtins.input',  mock_get_input)
    monkeypatch.setattr(src.actions.configure_proxy, 'write_env', mock_env)
    monkeypatch.setattr(os, 'mkdir', mock_mkdir)
    with pytest.raises(SystemExit):
        configure_proxy()
        assert True
    assert 'netskope-cls-config/env/common_config.env' in result


def test_pre_write_checks(monkeypatch):
    def mock_path(*args):
        return 'abc'
    monkeypatch.setattr(os.path, 'isdir', mock_path)
    pre_write_checks()
    assert os.path.isdir('abc')


@pytest.mark.parametrize('inp_val', [('n')])
def test_print_proxy_conclusion(monkeypatch, inp_val):
    simulator = SimulateUserInputs(inp_val)

    def mock_get_input(*args):
        return simulator.get_input()

    monkeypatch.setattr('builtins.input',  mock_get_input)