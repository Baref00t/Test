import os
import src
import pytest
from src.actions.install import install
from src.constants import CONFIG_DIR
from .constants import (
    install_cscc,
    install_syslog,
    install_sentinel,
    docker_config_dict_syslog,
    env_config_syslog,
    syslog_created_files,
    invalid_install_syslog
)


class SimulateUserInputs:

    def __init__(self, inputs):
        self.inputs = inputs
        self.count = 2

    def get_input(self):
        self.count += 1
        return self.inputs[self.count - 1]


configured_docker_file = None
configured_env = None
created_files = []

@pytest.mark.parametrize('input_value,expected_config, expected_env, expected_created_files', [
    (install_syslog, docker_config_dict_syslog, env_config_syslog, syslog_created_files),
    (invalid_install_syslog, None, None, [])])
def test_install(monkeypatch, input_value, expected_config, expected_env, expected_created_files):
    
    global configured_docker_file, configured_env, created_files
    configured_docker_file = None
    configured_env = None
    created_files = []

    simulator = SimulateUserInputs(input_value)

    def mock_get_input(*args):
        return simulator.get_input()

    monkeypatch.setattr('builtins.input',  mock_get_input)

    def mock_yml(*args):
        global configured_docker_file, created_files
        created_files.append(args[0])
        configured_docker_file = args[1]

        
    def mock_env(*args):
        global configured_env, created_files
        configured_env = args[0][0]['env_obj']
        created_files.append(args[0][0]['path'])
        return configured_env

    def mock_create_config_dir_structure(*args):
        return {
            'success': True,
            'copied_file': '',
            'key_name': ''
        }

    def mock_mkdir(*args):
        global created_files
        created_files.append(args[0])
    
    def mock_copy_proxy(*args):
        pass

    monkeypatch.setattr(os, 'mkdir', mock_mkdir)
    monkeypatch.setattr(src.actions.install, 'write_yml', mock_yml)
    monkeypatch.setattr(src.actions.install, 'write_env', mock_env)
    monkeypatch.setattr(src.actions.install,
                        'create_config_dir_structure', mock_create_config_dir_structure)
    monkeypatch.setattr(src.actions.install, 'copy_proxy_after_install', mock_copy_proxy)

    install()
    if not len(expected_created_files) == len(created_files):
        expected_created_files = expected_created_files[2:]
    assert (
        configured_docker_file == expected_config and
        configured_env == expected_env and
        created_files == expected_created_files
    )
