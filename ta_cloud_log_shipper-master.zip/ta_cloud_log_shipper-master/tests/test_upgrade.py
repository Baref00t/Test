import pytest
import os
from src.actions.action_helpers import (compare_template, check_for_env_updates,update_env_params, upgrade_image, git_pull, edit_env_file, upgrade_docker_compose)
from src.actions.upgrade import upgrade_without_configurations, upgrade_with_configurations
from src.helpers import write_env, read_env, read_yaml, write_yml
from src.actions.repair import save_backup
from src.constants import CONFIG_DIR
from .constants import old_template_2, updated_template_2, old_template_1, updated_template_1
import datetime
import glob
date = save_backup()
@pytest.mark.parametrize(('old_template, updated_template, expected'),[( old_template_2, updated_template_2,
{
    'KEY5': None,
    'KEY6': None
}),
( old_template_1,updated_template_1,
{
    'KEY4': None,
    'KEY5': None,
    'KEY6': None
}),
(
    {'key1': None}, {'key1': None}, {}
)
])
def test_compare_template(old_template, updated_template, expected):
    assert compare_template(old_template, updated_template) == expected

@pytest.mark.parametrize(('envs, date, expected'), [('syslog', date, []),
                                       ( 'cscc', date, [])])
def test_check_for_env_updates(monkeypatch, envs, date, expected):
    def mock_path():
        return ('/'+envs+'.env')
    monkeypatch.setattr(os.path, 'join', mock_path)
    assert check_for_env_updates([], date) == expected


def get_env_file():
    env_file = os.path.join('tests', CONFIG_DIR, 'partners_syslog.env')
    return env_file

def get_plugin():
    plugin = get_env_file().split('.')[0].split('_')[1]
    return plugin

def get_tenant():
    tenant = get_env_file().split('.')[0].split('_')[0]
    return tenant


@pytest.mark.parametrize('config_obj, date', 
[({
    'KEY1':None,
    'KEY2':None
}, date)])

def test_edit_env_file(capsys, monkeypatch, config_obj, date):
    #def mock_path():
    #    return ('/netskope-cls-config/env/{}_{}.env'.format(tenant,plugin))
    #monkeypatch.setattr(os.path, 'join', mock_path)
    def input_mock(*args):
        return 'VALUE1'
    # mock the input() function to mock user input
    monkeypatch.setattr('builtins.input', input_mock)
    edit_env_file(get_tenant(), get_plugin(), config_obj, date)
    assert  os.path.isfile(os.path.join(get_env_file()))

expected = {'path': 'tests/netskope-cls-config/docker-compose.yml', 'env_obj': {'SYSLOG_SERVER': None, 'SYSLOG_FORMAT': 'CEF', 'SYSLOG_PROTOCOL': None, 'SYSLOG_PORT': None, 'SYSLOG_CERT_FILE': None, 'SYSLOG_MAP': 'static/syslog_map.json', 'KEY1': 'Value'}}
env_obj = None
@pytest.mark.parametrize(('env_para, env, tenant, date, expected'), [({'KEY1': None}, get_plugin(), 'partners', date, expected)])
def test_add_env_para(monkeypatch, env_para, env, tenant, date, expected):
    def input_mock(*args):
        return 'Value1'

    def mock_path(*args, **kwargs):
        return ('tests/'+CONFIG_DIR+'/docker-compose.yml')

    def mock_yml(*args, **kwargs):
        return read_yaml(os.path.join('tests', CONFIG_DIR, 'docker-compose.yml'))
    
    def mock_edit_env(*args):
        return {
            'SYSLOG_SERVER': None,
            'SYSLOG_FORMAT': 'CEF',
            'SYSLOG_PROTOCOL': None,
            'SYSLOG_PORT': None,
            'SYSLOG_CERT_FILE': None,
            'SYSLOG_MAP': 'static/syslog_map.json',
            'KEY1': 'Value'
        }
    
    def mock_write_env(*args):
        global env_obj
        env_obj = args


    # mock the input() function to mock user input
    monkeypatch.setattr('builtins.input', input_mock)
    import src
    monkeypatch.setattr(src.actions.action_helpers, 'read_yaml', mock_yml)
    monkeypatch.setattr(os.path, 'join', mock_path)
    monkeypatch.setattr(src.actions.action_helpers, 'edit_env_file', mock_edit_env)
    monkeypatch.setattr(src.actions.action_helpers, 'write_env', mock_write_env)
    update_env_params(env_para, env, tenant, date)
    assert env_obj[0][0] == expected

add_var = {
    'KEY1':'VALUE1'
}

yml_dict = read_yaml(os.path.join('tests', CONFIG_DIR, 'docker-compose.yml'))['services']

@pytest.mark.parametrize('add_var, yml_dict,tenant, date, updated_image', [(add_var, yml_dict, 'partners',date, 'new_image')])
def test_upgrade_docker_compose(monkeypatch, add_var, yml_dict, tenant, date, updated_image):
    def input_mock(*args):
        return 'KEY1'

    # mock the input() function to mock user input
    monkeypatch.setattr('builtins.input', input_mock)
    docker_return = upgrade_docker_compose(add_var, yml_dict, tenant, date, updated_image)
    write_yml(os.path.join('tests', CONFIG_DIR, 'docker-compose.yml'), docker_return)
    assert docker_return == read_yaml(os.path.join('tests', CONFIG_DIR, 'docker-compose.yml'))


def test_git_pull():
    result = git_pull()
    if result:
        assert True
    else:
        assert not False


def test_upgrade_without_configurations(monkeypatch):
    def mock_path(*args):
        return 'tests/docker-compose.yml'

    monkeypatch.setattr(os.path, 'join', mock_path)

    upgrade_without_configurations()
    assert True


@pytest.mark.parametrize('date', [(date)])
def test_upgrade_with_configuration(monkeypatch, date):
    def mock_path(*args):
        return 'tests/docker-compose.yml'

    monkeypatch.setattr(os.path, 'join', mock_path)
    with pytest.raises(SystemExit):
        upgrade_with_configurations(date)
        assert True

@pytest.mark.parametrize('service_val, new_image', [({'image': 'old_image'}, 'new_image')])
def test_upgrade_image(service_val, new_image):
    assert upgrade_image(service_val, new_image) == {'image': 'new_image'}
