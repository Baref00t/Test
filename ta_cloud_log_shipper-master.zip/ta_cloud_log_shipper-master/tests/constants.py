docker_config = {
    'tenant_name': 'partners',
    'api_key': 'dummy_api_key',
    'alerts': 'all',
    'events': 'page',
    'alert_query': '',
    'event_query': '',
    'poll_interval': '',
    'time_period': '',
    'poll_offset': '',
    'enable_deduplication': 'n',
    'n_threads': '',
    'log_level': '',
    'enable_proxy': 'n'
}
syslog_config = {
    'syslog_server': 'localhost',
    'syslog_format': 'CEF',
    'syslog_protocol': 'UDP',
    'syslog_port': '',
    'syslog_map': ''
}
cscc_config = {
    'organization_id': 'dummy_org_id',
    'source_id': 'dummy_source_id',
    'cscc_map': ''
}
sentinel_config = {
    'workspace_id': 'dummy_workspace_id',
    'primary_key': 'dummy_primary_key',
    'sentinel_map': '',
    'alerts_log_type': '',
    'events_log_type': '',
}
update_syslog = ['2', '2', 
                'syslog',
                docker_config.get('tenant_name'),
                docker_config.get('api_key'),
                docker_config.get('alerts'),
                docker_config.get('events'),
                docker_config.get('alert_query'),
                docker_config.get('event_query'),
                docker_config.get('poll_interval'),
                docker_config.get('time_period'),
                docker_config.get('poll_offset'),
                docker_config.get('enable_deduplication'),
                docker_config.get('n_threads'),
                docker_config.get('log_level'),
                docker_config.get('enable_proxy'),
                syslog_config.get('syslog_server'),
                syslog_config.get('syslog_format'),
                syslog_config.get('syslog_protocol'),
                syslog_config.get('syslog_port'),
                syslog_config.get('syslog_map'),
                'n',
                'y']

update_cscc = ['2', '2', 
                'cscc',
                docker_config.get('tenant_name'),
                docker_config.get('api_key'),
                docker_config.get('alerts'),
                docker_config.get('events'),
                docker_config.get('alert_query'),
                docker_config.get('event_query'),
                docker_config.get('poll_interval'),
                docker_config.get('time_period'),
                docker_config.get('poll_offset'),
                docker_config.get('enable_deduplication'),
                docker_config.get('n_threads'),
                docker_config.get('log_level'),
                docker_config.get('enable_proxy'),
                cscc_config.get('organization_id'),
                cscc_config.get('source_id'),
                cscc_config.get('cscc_map'),
                'n',
                'y',
                'setup.py']
update_sentinel = ['2', '2', 
                'azure_sentinel',
                docker_config.get('tenant_name'),
                docker_config.get('api_key'),
                docker_config.get('alerts'),
                docker_config.get('events'),
                docker_config.get('alert_query'),
                docker_config.get('event_query'),
                docker_config.get('poll_interval'),
                docker_config.get('time_period'),
                docker_config.get('poll_offset'),
                docker_config.get('enable_deduplication'),
                docker_config.get('n_threads'),
                docker_config.get('log_level'),
                docker_config.get('enable_proxy'),
                sentinel_config.get('workspace_id'),
                sentinel_config.get('primary_key'),
                sentinel_config.get('sentinel_map'),
                sentinel_config.get('alerts_log_type'),
                sentinel_config.get('events_log_type'),
                'n',
                'y']

edit_syslog = ['2', '1','1', 
                'syslog',
                docker_config.get('tenant_name'),
                docker_config.get('api_key'),
                docker_config.get('alerts'),
                docker_config.get('events'),
                docker_config.get('alert_query'),
                docker_config.get('event_query'),
                docker_config.get('poll_interval'),
                docker_config.get('time_period'),
                docker_config.get('poll_offset'),
                docker_config.get('enable_deduplication'),
                docker_config.get('n_threads'),
                docker_config.get('log_level'),
                docker_config.get('enable_proxy'),
                syslog_config.get('syslog_server'),
                syslog_config.get('syslog_format'),
                syslog_config.get('syslog_protocol'),
                syslog_config.get('syslog_port'),
                syslog_config.get('syslog_map'),
                'n',
                'y']

edit_cscc = ['2', '1', '2',
                'cscc',
                docker_config.get('tenant_name'),
                docker_config.get('api_key'),
                docker_config.get('alerts'),
                docker_config.get('events'),
                docker_config.get('alert_query'),
                docker_config.get('event_query'),
                docker_config.get('poll_interval'),
                docker_config.get('time_period'),
                docker_config.get('poll_offset'),
                docker_config.get('enable_deduplication'),
                docker_config.get('n_threads'),
                docker_config.get('log_level'),
                docker_config.get('enable_proxy'),
                cscc_config.get('organization_id'),
                cscc_config.get('source_id'),
                cscc_config.get('cscc_map'),
                'n',
                'y',
                'setup.py']
edit_sentinel = ['2', '1', '1',
                'azure_sentinel',
                docker_config.get('tenant_name'),
                docker_config.get('api_key'),
                docker_config.get('alerts'),
                docker_config.get('events'),
                docker_config.get('alert_query'),
                docker_config.get('event_query'),
                docker_config.get('poll_interval'),
                docker_config.get('time_period'),
                docker_config.get('poll_offset'),
                docker_config.get('enable_deduplication'),
                docker_config.get('n_threads'),
                docker_config.get('log_level'),
                docker_config.get('enable_proxy'),
                sentinel_config.get('workspace_id'),
                sentinel_config.get('primary_key'),
                sentinel_config.get('sentinel_map'),
                sentinel_config.get('alerts_log_type'),
                sentinel_config.get('events_log_type'),
                'n',
                'y']

install_syslog = ['1', 'q','y', 
                'syslog',
                docker_config.get('tenant_name'),
                docker_config.get('api_key'),
                docker_config.get('alerts'),
                docker_config.get('events'),
                docker_config.get('alert_query'),
                docker_config.get('event_query'),
                docker_config.get('poll_interval'),
                docker_config.get('time_period'),
                docker_config.get('poll_offset'),
                docker_config.get('enable_deduplication'),
                docker_config.get('n_threads'),
                docker_config.get('log_level'),
                docker_config.get('enable_proxy'),
                syslog_config.get('syslog_server'),
                syslog_config.get('syslog_format'),
                syslog_config.get('syslog_protocol'),
                syslog_config.get('syslog_port'),
                syslog_config.get('syslog_map'),
                'n',
                'y']

install_cscc = ['1', 'q', 'y', 
                'cscc',
                docker_config.get('tenant_name'),
                docker_config.get('api_key'),
                docker_config.get('alerts'),
                docker_config.get('events'),
                docker_config.get('alert_query'),
                docker_config.get('event_query'),
                docker_config.get('poll_interval'),
                docker_config.get('time_period'),
                docker_config.get('poll_offset'),
                docker_config.get('enable_deduplication'),
                docker_config.get('n_threads'),
                docker_config.get('log_level'),
                docker_config.get('enable_proxy'),
                cscc_config.get('organization_id'),
                cscc_config.get('source_id'),
                cscc_config.get('cscc_map'),
                'n',
                'y',
                'setup.py']
install_sentinel = ['1', 'q', 'y', 
                'azure_sentinel',
                docker_config.get('tenant_name'),
                docker_config.get('api_key'),
                docker_config.get('alerts'),
                docker_config.get('events'),
                docker_config.get('alert_query'),
                docker_config.get('event_query'),
                docker_config.get('poll_interval'),
                docker_config.get('time_period'),
                docker_config.get('poll_offset'),
                docker_config.get('enable_deduplication'),
                docker_config.get('n_threads'),
                docker_config.get('log_level'),
                docker_config.get('enable_proxy'),
                sentinel_config.get('workspace_id'),
                sentinel_config.get('primary_key'),
                sentinel_config.get('sentinel_map'),
                sentinel_config.get('alerts_log_type'),
                sentinel_config.get('events_log_type'),
                'n',
                'y']
config = [
    
        'syslog',
        docker_config.get('tenant_name'),
        docker_config.get('api_key'),
        docker_config.get('alerts'),
        docker_config.get('events'),
        docker_config.get('alert_query'),
        docker_config.get('event_query'),
        docker_config.get('poll_interval'),
        docker_config.get('time_period'),
        docker_config.get('poll_offset'),
        docker_config.get('enable_deduplication'),
        docker_config.get('n_threads'),
        docker_config.get('log_level'),
        docker_config.get('enable_proxy')
]

config_with_none = [
    
        'syslog',
        docker_config.get('tenant_name'),
        docker_config.get('api_key'),
        docker_config.get('alerts'),
        docker_config.get('events'),
        docker_config.get('alert_query'),
        docker_config.get('event_query'),
        docker_config.get('poll_interval'),
        docker_config.get('time_period'),
        'None',
        docker_config.get('enable_deduplication'),
        docker_config.get('n_threads'),
        docker_config.get('log_level'),
        docker_config.get('enable_proxy')
]

del_syslog = [
    '2', '3', '1', 'y', 'delete', 'n'
]

del_sentinel = [
    '2', '3', '1', 'y', 'delete'
]

del_cscc = [
    '2', '3', '1', 'y', 'delete'
]

uninstall_cli = [
    '9', 'y', 'exit'
]
import os
edit_input = [ '1',
                'azure_sentinel',
                docker_config.get('tenant_name'),
                docker_config.get('api_key'),
                docker_config.get('alerts'),
                docker_config.get('events'),
                docker_config.get('alert_query'),
                docker_config.get('event_query'),
                docker_config.get('poll_interval'),
                docker_config.get('time_period'),
                docker_config.get('poll_offset'),
                docker_config.get('enable_deduplication'),
                docker_config.get('n_threads'),
                docker_config.get('log_level'),
                docker_config.get('enable_proxy'),
                sentinel_config.get('workspace_id'),
                sentinel_config.get('primary_key'),
                os.path.join('static', 'azure_sentinel_map.json'),
                sentinel_config.get('alerts_log_type'),
                sentinel_config.get('events_log_type'),
                'y',
                'n']

new_config = [
                'azure_sentinel',
                'abc',
                docker_config.get('api_key'),
                docker_config.get('alerts'),
                docker_config.get('events'),
                docker_config.get('alert_query'),
                docker_config.get('event_query'),
                docker_config.get('poll_interval'),
                docker_config.get('time_period'),
                docker_config.get('poll_offset'),
                docker_config.get('enable_deduplication'),
                docker_config.get('n_threads'),
                docker_config.get('log_level'),
                docker_config.get('enable_proxy'),
                sentinel_config.get('workspace_id'),
                sentinel_config.get('primary_key'),
                os.path.join('static', 'azure_sentinel_map.json'),
                sentinel_config.get('alerts_log_type'),
                sentinel_config.get('events_log_type'),
                'n',
                'y']

azure_config = [
                'azure_sentinel',
                'abc',
                docker_config.get('api_key'),
                docker_config.get('alerts'),
                docker_config.get('events'),
                docker_config.get('alert_query'),
                docker_config.get('event_query'),
                docker_config.get('poll_interval'),
                docker_config.get('time_period'),
                docker_config.get('poll_offset'),
                docker_config.get('enable_deduplication'),
                docker_config.get('n_threads'),
                docker_config.get('log_level'),
                docker_config.get('enable_proxy'),
                sentinel_config.get('workspace_id'),
                sentinel_config.get('primary_key'),
                os.path.join('static', 'azure_sentinel_map.json'),
                sentinel_config.get('alerts_log_type'),
                sentinel_config.get('events_log_type'),
                'n',
                'n']

del_service = [
    '1', 'y', 'delete', 'n'
]
old_template_2 = {
        'KEY1': 'VALUE1',
        'KEY2': 'VALUE2',
        'KEY3': None,
        'KEY4':'VALUE4'
}

updated_template_2 = {
    'KEY1': 'VALUE1',
    'KEY2': 'VALUE2',
    'KEY3': None,
    'KEY4':'VALUE4',
    'KEY5': None,
    'KEY6': None
}

old_template_1 = {

    'KEY1': 'VALUE1',
    'KEY2': 'VALUE2',
    'KEY3': None,
}
updated_template_1 = {
    'KEY1': 'VALUE1',
    'KEY2': 'VALUE2',
    'KEY3': None,
    'KEY4':None,
    'KEY5': None,
    'KEY6': None
}

docker_config_dict_syslog = {
    "version": "3",
    "services": {
        "partners_syslog.goskope.com": {
            "image": "hardikjani/mydockerimages:mcas_2",
            "network_mode": "host",
            "restart": "on-failure:5",
            "volumes": [
                "/etc/configs/partners_syslog:/opt/NetskopeCLS/src/config/:z",
                "/var/log/netskope_cls/partners_syslog:/opt/NetskopeCLS/src/logs/:z",
                "/etc/resolv.conf:/etc/resolv.conf",
                "/etc/localtime:/etc/localtime"
            ],
            "env_file": [
                "env/partners_syslog.env",
                "env/common_config.env"
            ],
            "environment": {
                "PLUGIN_TYPE": "syslog",
                "TENANT_NAME": "partners",
                "API_KEY": "dummy_api_key",
                "ALERT_TYPE": "all",
                "EVENT_TYPE": "page",
                "ALERT_QUERY": None,
                "EVENT_QUERY": None,
                "POLL_INTERVAL": 300,
                "TIME_PERIOD": 2592000,
                "POLL_OFFSET": 300,
                "ENABLE_DEDUPLICATION": "n",
                "N_THREADS": 2,
                "LOG_LEVEL": "INFO",
                "VERIFY_SSL": "True",
                "UNSORTED": "True"
            }
        }
    }
}

env_config_syslog = {
   "SYSLOG_SERVER":"n",
   "SYSLOG_FORMAT":"localhost",
   "SYSLOG_PROTOCOL":"CEF",
   "SYSLOG_PORT":"UDP",
   "SYSLOG_CERT_FILE":None,
   "SYSLOG_MAP":"static/syslog_map.json"
}

syslog_created_files = [
    'netskope-cls-config',
    'netskope-cls-config/env',
    'netskope-cls-config/docker-compose.yml',
    'netskope-cls-config/env/partners_syslog.env'
]

invalid_install_syslog = ['1', 'q','y', 
                'syslog',
                'test_tenant_name',
                docker_config.get('api_key'),
                docker_config.get('alerts'),
                docker_config.get('events'),
                docker_config.get('alert_query'),
                docker_config.get('event_query'),
                docker_config.get('poll_interval'),
                docker_config.get('time_period'),
                docker_config.get('poll_offset'),
                docker_config.get('enable_deduplication'),
                docker_config.get('n_threads'),
                docker_config.get('log_level'),
                docker_config.get('enable_proxy'),
                syslog_config.get('syslog_server'),
                syslog_config.get('syslog_format'),
                syslog_config.get('syslog_protocol'),
                syslog_config.get('syslog_port'),
                syslog_config.get('syslog_map'),
                'n',
                'y']