import pytest
from src.actions.uninstall import remove_images, uninstall
import os
from .constants import uninstall_cli, install_syslog, install_sentinel, install_cscc


class SimulateUserInputs:

    def __init__(self, inputs):
        self.inputs = inputs
        self.count = 0

    def get_input(self):
        self.count += 1
        return self.inputs[self.count - 1]


@pytest.mark.parametrize('input_value,expected', [
    (install_syslog, 'partners_syslog.env')])
#(install_sentinel, 'partners_azure_sentinel.env'),
# (install_cscc, 'partners_cscc.env')])
def test_install(monkeypatch, input_value, expected):

    simulator = SimulateUserInputs(input_value)

    def mock_get_input(*args):
        return simulator.get_input()

    monkeypatch.setattr('builtins.input',  mock_get_input)

    import os
    from src.main import setup
    from src.constants import CONFIG_DIR

    setup()

    assert (
        os.path.isdir(CONFIG_DIR)
        and os.path.isfile(os.path.join(CONFIG_DIR, 'docker-compose.yml'))
        and os.path.isdir(os.path.join(CONFIG_DIR, 'env'))
        and os.path.isfile(os.path.join(CONFIG_DIR, 'env', expected))
    )


@pytest.mark.parametrize('input_val', [
    (uninstall_cli)
])
def test_add_config(monkeypatch, input_val):
    simulator = SimulateUserInputs(input_val)

    def mock_get_input(*args):
        return simulator.get_input()

    monkeypatch.setattr('builtins.input', mock_get_input)

    from src.main import setup
    setup()

    assert (
        os.path.isdir('src')
    )


uninstall_input = ['y', 'exit']


@pytest.mark.parametrize('input_val', [
    (uninstall_input)
])
def test_uninstall(monkeypatch, input_val):
    simulator = SimulateUserInputs(input_val)

    def mock_get_input(*args):
        return simulator.get_input()

    monkeypatch.setattr('builtins.input', mock_get_input)

    assert not uninstall()


volumes = []
uninstall_input_remove = ['y', 'delete']
@pytest.mark.parametrize('inp_val', [(uninstall_input_remove)])
def test_uninstall_remove(monkeypatch, inp_val):
    simulator = SimulateUserInputs(inp_val)

    def mock_get_input(*args):
        return simulator.get_input()

    def mock_shutil(*args, **kwargs):
        global volumes
        volumes.append(args)

    def mock_is_installed(*args):
        return True

    def mock_stop_containers(*args):
        return True

    def mock_remove_image(*args):
        return True

    monkeypatch.setattr('builtins.input', mock_get_input)
    import shutil, src
    monkeypatch.setattr(shutil,'rmtree', mock_shutil)
    monkeypatch.setattr(src.actions.uninstall, 'is_installed', mock_is_installed)
    monkeypatch.setattr(src.actions.uninstall, 'check_and_stop_containers', mock_stop_containers)
    monkeypatch.setattr(src.actions.uninstall, 'remove_images', mock_remove_image)
    assert uninstall()
