import os
import pytest
import logging

from src.helpers import (
    clear,
    read_yaml,
    read_file,
    read_env,
    write_env,
    write_yml,
    get_input,
    is_installed,
    print_and_log,
    print_separator,
    validate_tenant,
    get_proxy_env
)


@pytest.fixture(scope='class')
def yml():
    yml_file = 'sample_yaml.yml'
    sample_yaml = '''a:
    b: b_value
    c: c_value'''

    yml_dict = {
        'a': {
            'b': 'b_value',
            'c': 'c_value'
        }
    }

    with open(yml_file, 'w') as yml:
        yml.write(sample_yaml)

    yield yml_file, yml_dict

    # Teardown
    os.remove(yml_file)


@pytest.fixture(scope='class')
def sample_file():
    text_file = 'sample_text.txt'
    content = 'sample_content'

    with open(text_file, 'w') as txt_file:
        txt_file.write(content)

    yield text_file, content

    # Teardown
    os.remove(text_file)


@pytest.fixture(scope='class')
def sample_env():
    env_file = 'sample.env'
    return env_file, [
        {
            'path': env_file,
            'env_obj': {
                'key1': 'val1',
                'key2': 'val2'
            }
        }
    ]


@pytest.fixture(scope='class')
def install_dir():
    dir_name = 'sample-config'

    # First create config dir
    os.mkdir(dir_name)

    # Create dummy docker compose file
    open(os.path.join(dir_name, 'docker-compose.yml'), 'w').close()

    return dir_name


def test_clear(monkeypatch):
    def mock_system(*args):
        assert args[0] == 'clear'

    import os

    monkeypatch.setattr(os, 'system', mock_system)
    clear()


@pytest.mark.parametrize(('input,expected'), [(10, 10), (100, 100)])
def test_print_separator(capfd, input, expected):
    print_separator(input)
    out, err = capfd.readouterr()
    print(out)
    assert len(out) - 1 == expected


def test_read_yaml(yml):
    yml_file, yml_dict = yml
    read_file = read_yaml(yml_file)
    assert read_file == yml_dict


def test_read_file(sample_file):
    file_name, content = sample_file
    read_content = read_file(file_name)
    assert read_content == content


def test_write_env(sample_env):
    env_file, env_obj = sample_env
    write_env(env_obj)

    with open(env_file, 'r') as env_file:
        env = env_file.read()
        assert env == 'key1=val1\nkey2=val2'


def test_write_yml():
    yml_obj = {
        'key1': 'val1',
        'key2': {
            'i_key1': 'i_val1'
        }

    }
    write_yml('sample.yml', yml_obj)

    # Now read it and assert
    assert read_yaml('sample.yml') == yml_obj


def test_read_env(sample_env):
    env_file, env_obj = sample_env
    write_env(env_obj)

    read_content = read_env(env_file)

    assert read_content == env_obj[0]['env_obj']


@pytest.mark.parametrize('input_value,expected,is_lower', [
    ('   input   ', 'input', True),
    ('   INPUT   ', 'input', True),
    ('INPUT', 'INPUT', False),
    (123, '123', True)
])
def test_get_input(monkeypatch, input_value, expected, is_lower):
    def input_mock(*args):
        return str(input_value)

    # mock the input() function to mock user input
    monkeypatch.setattr('builtins.input', input_mock)

    assert get_input('sample_text', is_lower) == expected


def test_is_installed(monkeypatch, install_dir):
    import src
    import importlib

    monkeypatch.setattr(src.constants, 'CONFIG_DIR', install_dir)

    # Need to reload imports after patching the constant
    importlib.reload(src.helpers)

    assert is_installed()

    # Now remove docker-compose.yml and assert again
    os.remove(os.path.join(install_dir, 'docker-compose.yml'))

    assert not is_installed()

    # Now remove the config file and assert again
    import shutil
    shutil.rmtree(install_dir)

    assert not is_installed()


@pytest.mark.parametrize('tenant, config_file, expected',
                         [('Partners', 'config_unauthenticated.env', True),
                          ('CSCC', 'config_unauthenticated.env', False),
                          ('sedemo', None, False)])
def test_validate_tenant(monkeypatch, tenant, config_file, expected):

    def mock_join(*args):
        return 'tests' + os.sep + config_file

    monkeypatch.setattr(os.path, 'join', mock_join)

    assert validate_tenant(tenant) == expected
