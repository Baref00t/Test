import os
import pytest
from src.actions.repair import edit_params, _add_new_integration, get_valid_path, save_backup, _edit_existing_integration, _delete_integration, repair
from src.constants import BKP_PATH, CONFIG_DIR
from src.helpers import write_env, read_yaml, read_env, write_yml
from .constants import (
    update_syslog,
    update_cscc,
    update_sentinel,
    edit_cscc,
    edit_sentinel,
    edit_syslog,
    config,
    del_cscc,
    del_sentinel,
    del_syslog,
    edit_input,
    new_config,
    del_service,
    azure_config,
    config_with_none,
    docker_config_dict_syslog,
    env_config_syslog,
    syslog_created_files,
    install_syslog
)


class SimulateUserInputs:

    def __init__(self, inputs):
        self.inputs = inputs
        self.count = 0

    def get_input(self):
        self.count += 1
        return self.inputs[self.count - 1]


configured_docker_file = None
configured_env = None
created_files = []


def check_install():
    num_services = 0
    if os.path.isfile(os.path.join(CONFIG_DIR, 'docker-compose.yml')):
        services = read_yaml(os.path.join(
            CONFIG_DIR, 'docker-compose.yml'))['services']
        num_services = len(services.keys())
    return num_services

# Install integration for testing
def install(monkeypatch):

    simulator = SimulateUserInputs(install_syslog)

    def mock_get_input(*args):
        return simulator.get_input()

    monkeypatch.setattr('builtins.input',  mock_get_input)

    import os
    from src.main import setup
    from src.constants import CONFIG_DIR

    setup()

# Add integration for testing
def add_integration(monkeypatch):
    from tests.constants import update_syslog
    update_syslog = update_syslog[2:]
    simulator = SimulateUserInputs(update_syslog)

    def mock_get_input(*args):
        return simulator.get_input()

    monkeypatch.setattr('builtins.input',  mock_get_input)

    import os
    from src.main import setup
    from src.constants import CONFIG_DIR

    _add_new_integration()

# Delete integration after testing
def delete(monkeypatch, input_val):

    simulator = SimulateUserInputs(input_val)

    def mock_get_input(*args):
        return simulator.get_input()

    monkeypatch.setattr('builtins.input',  mock_get_input)

    import os
    from src.main import setup
    from src.constants import CONFIG_DIR

    setup()


@pytest.mark.parametrize('input_val, expected_config, expected_env, expected_created_files', [
    (update_syslog, docker_config_dict_syslog,
     env_config_syslog, syslog_created_files)
])
def test_add_config(monkeypatch, input_val, expected_config, expected_env, expected_created_files):
    simulator = SimulateUserInputs(input_val)

    def mock_get_input(*args):
        return simulator.get_input()

    global configured_docker_file, configured_env, created_files
    configured_docker_file = None
    configured_env = None
    created_files = []

    def mock_yml(*args):
        global configured_docker_file, created_files
        created_files.append(args[0])
        configured_docker_file = args[1]

    def mock_read_yaml(*args):
        return read_yaml('tests'+os.sep+'netskope-cls-config'+os.sep+'docker-compose.yml')

    def mock_env(*args):
        global configured_env, created_files
        configured_env = args[0][0]['env_obj']
        created_files.append(args[0][0]['path'])
        return configured_env

    def mock_create_config_dir_structure(*args):
        return {
            'success': True,
            'copied_file': '',
            'key_name': ''
        }

    def mock_mkdir(*args):
        global created_files
        created_files.append(args[0])

    def mock_is_installed(*args):
        return True

    def mock_save_backup(*args):
        pass

    import os
    import src
    from src.main import setup

    monkeypatch.setattr(os, 'mkdir', mock_mkdir)
    monkeypatch.setattr(src.actions.repair, 'write_yml', mock_yml)
    monkeypatch.setattr(src.actions.repair, 'read_yaml', mock_read_yaml)
    monkeypatch.setattr(src.actions.repair, 'write_env', mock_env)
    monkeypatch.setattr(src.actions.repair,
                        'create_config_dir_structure', mock_create_config_dir_structure)
    monkeypatch.setattr(src.actions.repair, 'is_installed', mock_is_installed)
    monkeypatch.setattr(src.actions.repair, 'save_backup', mock_save_backup)
    monkeypatch.setattr('builtins.input', mock_get_input)

    setup()
    if not len(created_files) == len(expected_created_files):
        expected_created_files = expected_created_files[2:]
    assert (
        configured_docker_file == expected_config and
        configured_env == expected_env and
        created_files == expected_created_files
    )


@pytest.mark.parametrize('input_val, expected', [
    (edit_syslog, 'partners_syslog.env')
])
def test_edit_config(monkeypatch, input_val, expected):

    import os
    import src
    from src.main import setup
    from src.constants import CONFIG_DIR

    num_services = check_install()

    if num_services == 0:
        install(monkeypatch)
    else:
        add_integration(monkeypatch)

    input_val[2] = num_services + 1

    simulator = SimulateUserInputs(input_val)

    def mock_get_input(*args):
        return simulator.get_input()

    monkeypatch.setattr('builtins.input', mock_get_input)

    setup()
    is_config = os.path.isdir(CONFIG_DIR)
    is_docker_file = os.path.isfile(
        os.path.join(CONFIG_DIR, 'docker-compose.yml'))
    is_env = os.path.isdir(os.path.join(CONFIG_DIR, 'env'))
    is_env_file = os.path.isfile(os.path.join(CONFIG_DIR, 'env', expected))
    del_syslog[2] = str(num_services + 1)
    delete(monkeypatch, del_syslog)

    assert (
        is_config
        and is_docker_file
        and is_env
        and is_env_file
    )


@pytest.mark.parametrize('input, inp_val', [('1', edit_input), ('2', new_config)])
def test_repair(monkeypatch, input, inp_val):
    simulator = SimulateUserInputs(input)

    def mock_get_input(*args):
        return simulator.get_input()

    monkeypatch.setattr('builtins.input', mock_get_input)
    repair()
    if input == '1':
        test_edit_existing_param(monkeypatch, inp_val)
    if input == '2':
        test_add_config_param(monkeypatch, inp_val, True)


@pytest.mark.parametrize('file_type, tenant', [
    ('env', 'partners')])
def test_get_valid_path(monkeypatch, file_type, tenant):

    num_services = check_install()
    if num_services == 0:
        install(monkeypatch)
    else:
        add_integration(monkeypatch)

    def mock_get_input(*args):
        return os.path.join(CONFIG_DIR, 'env', '{}_syslog.env'.format(tenant))

    monkeypatch.setattr('builtins.input', mock_get_input)
    file = get_valid_path(file_type, tenant)
    is_file = os.path.exists(file)
    del_syslog[2] = str(num_services + 1)
    delete(monkeypatch, del_syslog)
    assert is_file


def test_save_backup(monkeypatch):

    num_services = check_install()
    if num_services == 0:
        install(monkeypatch)
    else:
        add_integration(monkeypatch)

    date = save_backup()
    is_exists = os.path.isdir(os.path.join(
        BKP_PATH, 'cls_backup_{}'.format(date.strftime("%Y-%m-%dT%Hh%Mm%Ss"))))

    del_syslog[2] = str(num_services + 1)
    delete(monkeypatch, del_syslog)

    assert is_exists


config_obj = {
    'PLUGIN_TYPE': 'syslog',
    'TENANT_NAME': 'abc',
    'API_KEY': '',
    'ALERT_TYPE': 'all',
    'EVENT_TYPE': '',
    'ALERT_QUERY': '',
    'EVENT_QUERY': '',
    'POLL_INTERVAL': 300,
    'TIME_PERIOD': 2592000,
    'POLL_OFFSET': 300,
    'ENABLE_DEDUPLICATION': 'no',
    'N_THREADS': 2,
    'LOG_LEVEL': 'INFO',
    'ENABLE_PROXY': 'no',

}

expected = {
    'PLUGIN_TYPE': 'syslog',
    'TENANT_NAME': 'partners',
    'API_KEY': 'dummy_api_key',
    'ALERT_TYPE': 'all',
    'EVENT_TYPE': 'page',
    'ALERT_QUERY': None,
    'EVENT_QUERY': None,
    'POLL_INTERVAL': 300,
    'TIME_PERIOD': 2592000,
    'POLL_OFFSET': 300,
    'ENABLE_DEDUPLICATION': 'n',
    'N_THREADS': 2,
    'LOG_LEVEL': 'INFO',
    'ENABLE_PROXY': 'n',

}

expected_with_none = {
    'PLUGIN_TYPE': 'syslog',
    'TENANT_NAME': 'partners',
    'API_KEY': 'dummy_api_key',
    'ALERT_TYPE': 'all',
    'EVENT_TYPE': 'page',
    'ALERT_QUERY': None,
    'EVENT_QUERY': None,
    'POLL_INTERVAL': 300,
    'TIME_PERIOD': 2592000,
    'POLL_OFFSET': None,
    'ENABLE_DEDUPLICATION': 'n',
    'N_THREADS': 2,
    'LOG_LEVEL': 'INFO',
    'ENABLE_PROXY': 'n',

}


@pytest.mark.parametrize('config_obj, input_val, excluded, expected',
                         [(config_obj, config, ['PLUGIN_TYPE, TENANT_NAME', 'UNSORTED'], expected)])
def test_edit_params(monkeypatch, config_obj, input_val, excluded, expected):
    simulator = SimulateUserInputs(input_val)

    def mock_get_input(*args):
        return simulator.get_input()

    monkeypatch.setattr('builtins.input', mock_get_input)

    del expected['API_KEY']
    edited = edit_params(config_obj, excluded)
    if 'API_KEY' in edited:
        del edited['API_KEY']
    assert edited == expected


@pytest.mark.parametrize('inp_val', [(edit_input)])
def test_edit_existing_param(monkeypatch, inp_val):

    import src
    num_services = check_install()

    if num_services == 0:
        install(monkeypatch)
    else:
        add_integration(monkeypatch)

    inp_val[2] = str(num_services + 1)

    simulator = SimulateUserInputs(inp_val)

    def mock_get_input(*args):
        return simulator.get_input()

    def mock_containers(*args):
        return True

    monkeypatch.setattr('builtins.input', mock_get_input)
    monkeypatch.setattr(src.actions.repair, 'check_and_stop_multiple_containers', mock_containers)
    _edit_existing_integration()
    is_config = os.path.isdir(CONFIG_DIR)
    is_docker_file = os.path.isfile(
        os.path.join(CONFIG_DIR, 'docker-compose.yml'))
    is_env = os.path.isdir(os.path.join(CONFIG_DIR, 'env'))
    del_syslog[2] = str(num_services + 1)
    delete(monkeypatch, del_syslog)

    assert (
        is_config
        and is_docker_file
        and is_env
    )


configured_docker_file = None
configured_env = None
created_files = []

@pytest.mark.parametrize('inp_val, expected', [(new_config, True), (azure_config, False)])
def test_add_config_param(monkeypatch, inp_val, expected):
    simulator = SimulateUserInputs(inp_val)

    def mock_get_input(*args):
        return simulator.get_input()

    global configured_docker_file, configured_env, created_files
    configured_docker_file = None
    configured_env = None
    created_files = []

    def mock_yml(*args):
        global configured_docker_file, created_files
        created_files.append(args[0])
        configured_docker_file = args[1]

    def mock_read_yaml(*args):
        return read_yaml('tests'+os.sep+'netskope-cls-config'+os.sep+'docker-compose.yml')

    def mock_env(*args):
        global configured_env, created_files
        configured_env = args[0][0]['env_obj']
        created_files.append(args[0][0]['path'])
        return configured_env

    def mock_create_config_dir_structure(*args):
        return {
            'success': True,
            'copied_file': '',
            'key_name': ''
        }

    def mock_mkdir(*args):
        global created_files
        created_files.append(args[0])

    def mock_is_installed(*args):
        return True

    import os
    import src

    monkeypatch.setattr(os, 'mkdir', mock_mkdir)
    monkeypatch.setattr(src.actions.repair, 'write_yml', mock_yml)
    monkeypatch.setattr(src.actions.repair, 'read_yaml', mock_read_yaml)
    monkeypatch.setattr(src.actions.repair, 'write_env', mock_env)
    monkeypatch.setattr(src.actions.repair,
                        'create_config_dir_structure', mock_create_config_dir_structure)
    monkeypatch.setattr(src.actions.repair, 'is_installed', mock_is_installed)
    monkeypatch.setattr('builtins.input', mock_get_input)

    assert _add_new_integration() == expected


@pytest.mark.parametrize('input_val, expected', [
    (del_syslog, 'partners_syslog.env'),
])
def test_delete_config(monkeypatch, input_val, expected):
    num_services = check_install()
    if num_services == 0:
        install(monkeypatch)
        num_services += 1
    else:
        add_integration(monkeypatch)
        num_services += 1

    input_val[2] = str(num_services)
    simulator = SimulateUserInputs(input_val)

    def mock_get_input(*args):
        return simulator.get_input()

    monkeypatch.setattr('builtins.input', mock_get_input)

    import os
    from src.main import setup

    setup()

    assert True


@pytest.mark.parametrize('inp_val', [('q')])
def test_delete_integration(monkeypatch, inp_val):
    simulator = SimulateUserInputs(inp_val)

    def mock_get_input(*args):
        return simulator.get_input()

    def mock_read_yaml(*args):
        return read_yaml(os.path.join('tests', CONFIG_DIR, 'docker-compose.yml'))

    import src

    monkeypatch.setattr('builtins.input', mock_get_input)
    monkeypatch.setattr(src.actions.repair, 'read_yaml', mock_read_yaml)

    assert _delete_integration()
