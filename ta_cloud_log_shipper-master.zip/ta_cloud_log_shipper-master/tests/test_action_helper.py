from src.constants import BKP_PATH, TEMPLATE_DIR, CONFIG_DIR
import pytest
from src.actions.action_helpers import (
    check_and_stop_containers, is_container_running, get_running_cls_containers,validate, check_and_stop_multiple_containers, upgrade_postprocess, configure_env, create_config_dir_structure, validate_mapping_file_path)
from src.actions.repair import save_backup

import os
import datetime
from tests.constants import del_syslog
from src.helpers import read_yaml, write_yml, read_env, write_env
from src.actions.upgrade import upgrade_with_configurations, upgrade_without_configurations
from .constants import install_syslog
date = datetime.datetime.now()

is_install = False

class SimulateUserInputs:

    def __init__(self, inputs):
        self.inputs = inputs
        self.count = 0

    def get_input(self):
        self.count += 1
        return self.inputs[self.count - 1]


def check_install():
    num_services = 0
    if os.path.isfile(os.path.join(CONFIG_DIR, 'docker-compose.yml')):
        services = read_yaml(os.path.join(
            CONFIG_DIR, 'docker-compose.yml'))['services']
        num_services = len(services.keys())
    return num_services

# Delete integration after testing
def delete(monkeypatch, input_val):

    simulator = SimulateUserInputs(input_val)

    def mock_get_input(*args):
        return simulator.get_input()
    
    def mock_container(*args):
        return True

    monkeypatch.setattr('builtins.input',  mock_get_input)
    import src
    monkeypatch.setattr(src.actions.repair, 'check_and_stop_containers', mock_container)

    from src.main import setup

    setup()


@pytest.mark.parametrize('input_value,expected', [
    (install_syslog, 'partners_syslog.env')])
def test_install(monkeypatch, input_value, expected):
    global date
    simulator = SimulateUserInputs(input_value)

    def mock_get_input(*args):
        return simulator.get_input()

    monkeypatch.setattr('builtins.input',  mock_get_input)

    import os
    from src.main import setup
    from src.constants import CONFIG_DIR
    num_services = check_install()
    if num_services == 0:
        setup()
        global is_install
        is_install = True
        date = save_backup()
        assert (
            os.path.isdir(CONFIG_DIR)
            and os.path.isfile(os.path.join(CONFIG_DIR, 'docker-compose.yml'))
            and os.path.isdir(os.path.join(CONFIG_DIR, 'env'))
            and os.path.isfile(os.path.join(CONFIG_DIR, 'env', expected))
        )
    else:
        assert True


@pytest.mark.parametrize('container, inp_val', [([], 'n'), ['container_cls', 'n']])
def test_check_and_stop_container(monkeypatch, container, inp_val):
    simulator = SimulateUserInputs(inp_val)

    def mock_get_input(*args):
        return simulator.get_input()
    import src
    def mock_container(*args):
        return True

    monkeypatch.setattr('builtins.input',  mock_get_input)
    monkeypatch.setattr(src.actions.action_helpers, 'is_container_running', mock_container)

    if len(container) > 0:
        simulator = SimulateUserInputs(inp_val)

        def mock_get_input(*args):
            return simulator.get_input()

        def mock_container(*args):
            return True

        import src
        monkeypatch.setattr('builtins.input',  mock_get_input)
        monkeypatch.setattr(src.actions.action_helpers, 'is_container_running', mock_container)
        assert not check_and_stop_containers()
    else:
        assert not check_and_stop_containers()


@pytest.mark.parametrize('service, inp_val', [('partners_syslog.goskope.com', 'y')])
def test_check_and_stop_multiple_containers(monkeypatch, service, inp_val):
    simulator = SimulateUserInputs(inp_val)
    import src

    def mock_container_running(*args):
        return True

    def mock_get_input(*args):
        return simulator.get_input()

    def mock_stop_container(*args):
        return True

    monkeypatch.setattr('builtins.input', mock_get_input)
    monkeypatch.setattr(src.actions.action_helpers, 'stop_containers', mock_stop_container)
    monkeypatch.setattr(src.actions.action_helpers, 'is_container_running', mock_container_running)
    assert check_and_stop_multiple_containers(service)


@pytest.mark.parametrize('key, value, message', [
    ('PLUGIN_TYPE', 'CSCC', 'Wrong_input'), ('ENABLE_PROXY', 'y', 'Wrong_input'), ('PROXY_SCHEME', 'https', 'wrong_input')])
def test_validate(monkeypatch, key, value, message):
    assert validate(key, value, message) == value


read_template_docker = \
    read_yaml(os.path.join('tests', 'docker-compose.yml'))[
        'services']['<tenant_name>.goskope.com'][
        'environment']
inp_val = [
    '', '', '', '', '', '', '', ''
]


@pytest.mark.parametrize(
    'len_template, tenants, change_in_envs, read_template_docker, inp_val', [
        (15, 'partners', [], read_template_docker, inp_val)])
def test_upgrade_postprocess(monkeypatch, len_template, tenants, change_in_envs, read_template_docker, inp_val):
    global date
    simulator = SimulateUserInputs(inp_val)

    def mock_get_input(*args):
        return simulator.get_input()

    def mock_yml(*args):
        return write_yml(os.path.join('tests', 'netskope-cls-config', 'docker-compose.yml'), args[1])

    def mock_container_running():
        return False
    import os
    import src
    monkeypatch.setattr('builtins.input',  mock_get_input)
    monkeypatch.setattr(src.actions.action_helpers, 'write_yml', mock_yml)
    monkeypatch.setattr(src.actions.action_helpers, 'is_container_running', mock_container_running)

    services = read_yaml(
    os.path.join('tests', 'netskope-cls-config', 'docker-compose.yml'))[
    'services']

    upgrade_postprocess(len_template, tenants, services,
                            date, change_in_envs, read_template_docker, False)
    assert True


@pytest.mark.parametrize('date', [(date)])
def test_upgrade_with_configurations(date):
    with pytest.raises(SystemExit):
        upgrade_with_configurations(date)
        assert True
    
    assert True


def test_upgrade_without_configurations():
    with pytest.raises(SystemExit):
        upgrade_without_configurations()
        assert True
    
    assert True

@pytest.mark.parametrize('date, inp_val', [(date, 'y')])
def test_upgrade_with_configuration(monkeypatch, date, inp_val):
    simulator = SimulateUserInputs(inp_val)

    def mock_get_input(*args):
        return simulator.get_input()

    monkeypatch.setattr('builtins.input',  mock_get_input)

    with pytest.raises(SystemExit):
        upgrade_with_configurations(date)
        assert True
    assert True


@pytest.mark.parametrize('plugin, tenant, volumes, syslog_protocol, path', [
    ('cscc', 'partners', ['tests/test1','tests/test2'], 'UDP', 'tests/config_authenticated.yml'),
    ('syslog', 'partners', ['tests/test1','tests/test2'], 'tls', 'tests/config_authenticated.yml'),
    ('azure_sentinel', 'partners', ['tests/test1','tests/test2'], 'tls', 'tests/config_authenticated.yml')
])
def test_create_config_dir_struucture(monkeypatch, plugin, tenant, volumes, syslog_protocol, path):
    simulator = SimulateUserInputs(path)
    def mock_get_input(*args):
        return simulator.get_input()

    def mock_copy_file(*args):
        return True

    import src

    monkeypatch.setattr('builtins.input',  mock_get_input)
    monkeypatch.setattr(src.actions.action_helpers, 'copy_file', mock_copy_file)
    result = create_config_dir_structure(plugin, tenant, volumes, syslog_protocol, path)
    for volume in volumes:
        os.rmdir(volume)
    assert result['success']


@pytest.mark.parametrize('input', [('tests/constants.py')])
def test_validate_mapping_file_path(input):
    assert validate_mapping_file_path(input) == input

inp_val = ['10.0.9.120', 'CEF', 'UDP', 514, 'tests/constant.py']
@pytest.mark.parametrize('plugin, tenant, inp_val', [('syslog', 'partners', inp_val)])
def test_configure_env(monkeypatch, plugin, tenant, inp_val):
    simulator = SimulateUserInputs(inp_val)

    def mock_path(*args):
        return 'tests/syslog.env'

    def mock_get_input(*args):
        return simulator.get_input()

    monkeypatch.setattr('builtins.input',  mock_get_input)
    monkeypatch.setattr('builtins.input',  mock_path)
    
    result = configure_env(plugin, tenant)['success']
    global is_install
    if is_install:
        num_services = check_install()
        del_syslog[2] = str(num_services)
        delete(monkeypatch, del_syslog)
    assert result


def test_is_container_running(monkeypatch):

    def mock_running_container(*args):
        return ['cls_container']

    import src

    monkeypatch.setattr(src.actions.action_helpers, 'get_running_cls_containers', mock_running_container)
    assert is_container_running()