#!/usr/bin/env python3

from src.main import run

if __name__ == '__main__':
    """
    Entry point for installer.
    """
    try:
        run()
    except KeyboardInterrupt:
        print('\nExiting from the setup.')
