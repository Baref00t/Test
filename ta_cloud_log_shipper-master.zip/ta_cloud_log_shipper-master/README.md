# Netskope Cloud Log Shipper (Version 2.0.0)

## PREREQUISITES

* GIT
* Docker
* Docker-compose
* pip3
* Logged in as a user with sudo privileges

At present, you can install CLS with any of the four available plugins: CSCC, SYSLOG, AZURE_SENTINEL and MCAS. You would be required to have below mentioned additional prerequisites.

## Google Cloud SCC (CSCC) Plugin

  1. Required Google Cloud platform credentials with "Editor" role on a particular project.
  2. Create Google Service Account on GCP.
  3. Provide "Security Center Admin" permission to your service account on GCP.
  4. Enable Cloud Security Command Center API [Click here](https://console.cloud.google.com/apis/library/securitycenter.googleapis.com)
  5. Enable Cloud Resource Manager API [Click here](https://console.cloud.google.com/apis/library/cloudresourcemanager.googleapis.com)
  6. Google Cloud SCC must be enabled for your Google Organization. Refer to Quickstart for Cloud SCC for more information.
  7. Keep Google service account key json file handy with you on the host machine.

## Syslog Plugin

  1. Credentials and required access for SIEM platform.
  2. If you are going to use TLS protocol for data transfer using CLS then keep your CA signed certificate generated from SIEM platform handy. CLS would ask you for CA signed certificate path while using TLS protocol.
  
      **Note**: CLS uses Micro Focus - ArcSight CEF standards, as a base line for the SYSLOG attribute mappings.

## Azure Sentinel Plugin

  1. A Log Analytics Workspace is required on Azure Sentinel platform in order to ingest data.
  2. To create a workspace on Azure Sentinel, go to [Azure Portal](https://portal.azure.com/) and from "**All Services**", select "**Azure Sentinel**". This will list all the available workspaces in your account.
  3. Click on "**+**" icon in top left, which allows to add an existing workspace to Azure Sentinel or to create a new workspace.
  4. If you have a workspace already created but not added to Azure Sentinel, select it from the list and click "**Add to Azure Sentinel**" button or click on "**Create new Workspace**" button to create a new workspace.
  5. Enter required details in the form and press "**Review+Create**". After reviewing your inputs, click on "**Create**". Now workspace is created but not added to Azure Sentinel. Refer step 2, 3 and 4 to add it into Azure Sentinel.
  6. To get workspace ID and primary key, Navigate to Home > Log Analytics workspaces > select the newly added workspace > select "**Advanced Settings**" from left navigation bar of your workspace. From the right most section, copy "WORKSPACE ID" and "PRIMARY KEY" fields, which will be used during installation.

## Microsoft Cloud Application Security (MCAS) Plugin

  1. An API token and a data-source is required on MCAS portal in order to upload traffic logs.
  2. Here are the steps to create a new data-source on MCAS portal:
      1. Login to your MCAS portal and click on settings icon on top right corner.
      2. Select "**Log Collectors**" from the drop down menu.
      3. Under the "**Automatic Log Upload**" section, select the "**Data Sources**" tab and then click on "**Add data source...**" button.
      4. In the opened pop up form, enter the name of your choice and select "Generic CEF log" in "Source" field and for "Receiver type", select any of the Syslog protocol. 
      5. Click "**Add**". 
      6. This will create a new data-source on your MCAS portal.
  3. Here are the steps to get an API token in order to upload traffic logs on MCAS portal:
      1. Click on settings icon on top right corner and select "**Security extensions**" from the drop down menu.
      2. Under the "Security extensions" section, select the "**API tokens**" tab.
      3. Click on the "**+**" button located at the right side to create a new API token for CLS. This will open a pop up.
      4. Enter the name of API token and click on "**Generate**".
      5. It’ll generate a new API token, copy it and store it at a secure location. It’ll also show the portal URL, which will be used for configuration of CLS.


## RELEASE NOTES

### Version 2.0.0

Welcome to the 2.0.0 release of Netskope Cloud Log Shipper.

## INSTALL CLS

### Using CLS Installer

You can perform install, repair, upgrade, proxy configuration and uninstall operations using the CLS Installer.

* mkdir netskope
* cd netskope
* sudo git clone https://github.com/netskopeoss/ta_cloud_log_shipper
* cd ta_cloud_log_shipper
* sudo pip3 install -r requirements.txt
* User has to change the permission of setup file to execute it before running,
  * sudo chmod +x setup.py
* sudo ./setup.py

## CLI Configurations

CLS Installer will drive you through below configurations. You do not need to go and modify this configuration in any file.
CLS installer will ask you for these configurations and automatically update required configuration file under the hood.

### Common Configurations

  1. PLUGIN_TYPE - One of CSCC, SYSLOG, AZURE_SENTINEL or MCAS
  2. TENANT_NAME - Tenant Name which should not contain .goskope.com so if your tenant name is partners.goskope.com here you have to write "partners" as a tenant name.
  3. API_KEY - Netskope API key. This will be encrypted once you save the configurations
  4. ALERT_TYPE - Alert types with comma separation i.e. anomaly, DLP, malware, policy, Compromised Credential, Legal Hold, Malsite, Quarantine, Remediation, Security Assessment, Watchlist (default: all)
  5. EVENT_TYPE - Event types with comma separation i.e application, page, infrastructure, audit, network (default: "") 
  **Note**: for MCAS plugin, default event types will be page and application
  6. ALERT_QUERY - Helps to filter alerts (default: empty)
  7. EVENT_QUERY - Helps to filter events (default: empty)
  8. POLL_INTERVAL - Interval between each poll in seconds (default: 300)
  9. TIME_PERIOD - Netskope API supports below TIME_PERIOD values. [3600 , 86400 , 604800 , 2592000 , 7776000] By default 30 days (i.e 2592000) would be applied as a TIME_PERIOD
  10. POLL_OFFSET - Helps to ensure that we do not loose any records. (default: 300)
  11. ENABLE_DEDUPLICATION: Whether the data deduplication is enabled or not.
  12. N_THREADS - Number of threads which helps to post data to SIEM platform(s). (default: 2)
  13. LOG_LEVEL - Require for log file generation. Supported LOG_LEVEL value is INFO, DEBUG, ERROR, WARNING (default: INFO)

### Plugin specific configurations

#### Google Cloud SCC (CSCC) Plugin

  1. ORGANIZATION_ID - Organization ID of GCP
  2. SOURCE_ID - GCP Source Id
  3. KEY_FILE - Key file
  4. CSCC_MAP - Attribute mapping file. Default file located at: static/cscc_map.json

#### Syslog Plugin

  1. SYSLOG_SERVER - IP address/FQDN of syslog server
  2. SYSLOG_FORMAT - CEF (default: CEF)
  3. SYSLOG_PROTOCOL - TLS | UDP | TCP (default: UDP)
  4. SYSLOG_PORT - Syslog port
  5. SYSLOG_CERT_FILE - certificate file required only for TLS protocol
  6. SYSLOG_MAP - Attribute mapping file. Default file located at: static/syslog_map.json

#### Azure Sentinel Plugin

  1. WORKSPACE_ID - Unique identifier of your Azure Sentinel Workspace
  2. PRIMARY_KEY - An authentication key for your Azure Sentinel Workspace. This will be encrypted once you save the configurations
  3. AZURE_SENTINEL_MAP - Attribute mapping file. Default file located at: static/azure_sentinel_map.json
  4. ALERTS_LOG_TYPE_NAME - Custom Log Type name for alerts. Based on this name, schema for alerts will be created in Log Analytics Workspace with suffix "_CL" (default: Netskope_Alerts)
  5. EVENTS_LOG_TYPE_NAME - Custom Log Type name for events. Based on this name, schema for events will be created in Log Analytics Workspace with suffix "_CL" (default: Netskope_Events)

#### Microsoft Cloud Application Security (MCAS) Plugin

  1. PORTAL_URL - MCAS portal URL, in which the traffic logs are to be ingested. The URL will be in the form of "<mcas_tenant_name>.\<region>.portal.cloudappsecurity.com"
  2. API_TOKEN - MCAS portal's API token for authentication from CLS to MCAS. This will be encrypted once you save the configurations
  3. DATA_SOURCE - The data source in which the traffic logs are to be uploaded from CLS
  4. MCAS_MAP - Attribute mapping file for MCAS. Default file located at: static/mcas_map.json

## Proxy Support
CLS also supports inbound and outbound proxy configuration via separate installation option in CLI. Following are the parameters required to be configured for setting up the proxy:

  1. ENABLE_PROXY: Whether the proxy is enable or not. (by default proxy is disabled)
  2. PROXY_SCHEME: Proxy scheme (either HTTPS/HTTP, default: HTTPS)
  3. PROXY_SERVER: IP Address/FQDN of the proxy server
  4. PROXY_PORT: Proxy port
  5. AUTHENTICATED_PROXY: Whether the proxy is authenticated or not (default: no)
  6. USERNAME: Proxy username in case of authenticated proxy
  7. PASSWORD: Proxy password in case of authenticated proxy. This will be encrypted once you save the configurations
  
  **Note**: Outbound proxy is not supported for Syslog plugin.

### SSL Support
This is an advanced manual configuration, by default CLS uses SSL verification for API calls. If you want to change this configuration, you can change the value of "VERIFY_SSL" flag in docker-compose.yml file.

## ASSUMPTIONS AND TRADE-OFFS

* We strongly discourage the use of multiple CLS on a single machine. 
* Upgrade support is only supported from CLS v2.0.0. If you are already using CLS v1.0.0 then you have to uninstall and then install CLS v2.0.0.
* A combination of tenant name & plugin type should be unique across all integrations.
* Once you install any CLS integration using installer, you would not be able to change tenant name and plugin type parameter for the existing integration(s). However if you want to change either tenant name or plugin type, you would have to remove integration by running installer in repair mode. And again add new integration using repair mode.
* Users must have to use CLS installer to perform any operation like install, repair, upgrade, proxy configuration or uninstall.
* When you run the CLS very first time, it can max pull up to 90 days of historical data. During this process, unless deduplication is enabled, we are recommending that make sure you do not stop the container and if you stop it or the docker process will be interrupted/killed, then the CLS would not be able to store the checkpoint hence in the next successful polling you would have duplicate alerts.
* If de-duplication is enabled, the data ingestion would be sequential and can take longer than usual.
* Supports DLP, anomaly, malware, policy, Compromised Credentials, Legal Hold, Malsite, Quarantine, Remediation, Security Assessment and Watchlist alert types (except for MCAS plugin, which does not support Alerts).
* Supports infrastructure, page, application, network and audit event types (except for MCAS plugin, which only supports page and application)
* CLS can pull max up to 500000 historical data using Netskope API.
* We are not supporting the upgrade when any existing field is changed or removed (In docker-compose.yml or plugin environment file).
* In case of an upgrade, if any new integration is added, users will have to install the integration using the repair option.
* Once the CLS has been started, in order to reflect changes made in the custom mapping file, the CLS has to be reconfigured or the user directly needs to make the changes in the mapping files in the mapped volume itself.
* It is assumed that the proxy parameters will not change, and hence upgrade is not supported for proxy.
* For MCAS plugin, CLS won’t track the status of cloud application discovery run by the portal, on the data that is uploaded. If the data uploaded successfully, CLS would progress further irrespective of the status of the cloud application discovery because it is an asynchronous process.


## TROUBLESHOOTING

* If on the host machine, user is not logged into docker hub account he would require to login using below command,
  * `sudo docker login`
* While configuring the tenant name via CLI, if it gives error even with valid tenant name, make sure that the tenant is reachable (either directly or via a valid proxy).
* If Docker daemon is not running on your host machine, when you trigger 'docker-compose up -d' command, you will get following error: `Error: Couldn't connect to Docker Daemon at http+docker://localhost - is it running?If it's at a non-standard location, specify the URL with the DOCKER_HOST environment variable.`. In order to start the docker daemon, use the following command: `sudo service docker start`.
* You can gracefully exit from CLI at any stage via pressing "Ctrl+C".
* You can find installation setup logs at, `/var/log/netskope_cls/setup_logs/setup.log`
* By default `INFO` level is configured. Set LOG_LEVEL to `DEBUG` level to see debug level logs using CLS Installer (Repair option) If you are not able to start container successfully or if data ingestion has any problem or facing any other issues then please check `/var/log/netskope_cls/<tenant-name>/<tenant-name>.log` file for loggers and debugging information.
* In Syslog or MCAS plugin, if transformation of some of the fields are being ignored because of its size limit, you can change their "Length" field in `valid_extension.csv` file. Here is one such example of log, which indicates this situation: `An Error occurred while generating CEF data for field <field_name>. Error: <field_name> String length out of range <range>. Field will be ignored.` 
* How to know running containers?
  * `sudo docker ps`
* How to get into a container?
  * `sudo docker exec -it <container id> sh`
* How can I validate a modified docker-compose.yml file?
  * `sudo docker-compose config`
* Where can I find container logs on centOS and Ubuntu?
  * `CentOS - sudo journalctl -u docker.service`
  * `Ubuntu - sudo journalctl -fu docker.service`
* How can you stop all running CLS containers? Reach to the directory where your docker-compose.yml file resides and execute below command, it will stop all the docker containers which were started using docker-compose.
  * `docker-compose down`
* How can you stop a specific container?
  * `docker stop <container-id>`
* If you found below "Max retries" error (with Errno -3) in CLS log file, Error: Max retries exceeded with url: /api/v1/alerts?token=token&query=&type=malware&limit=5000&skip=0&starttime=1562065215&endtime=1569841215 (Caused by NewConnectionError('<urllib3.connection.VerifiedHTTPSConnection object at 0x7fbe8b584750>: Failed to establish a new connection: [Errno -3] Try again')) To resolve above error you would have to enable ipv4 IP forwarding,
  * Stop docker container (if it's running)
  * Check the current value, `/sbin/sysctl net.ipv4.conf.all.forwarding`
  * Enable the setting, `/sbin/sysctl -w net.ipv4.conf.all.forwarding=1`
  * Start the docker container(s)
