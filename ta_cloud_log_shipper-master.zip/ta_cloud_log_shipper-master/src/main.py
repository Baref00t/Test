from importlib import reload

from . import constants
from . import helpers
from .actions import install
from .actions import repair
from .actions import uninstall
from .actions import upgrade
from .actions import configure_proxy
from . import logger_manager


def refresh_imports():
    global constants, helpers, install, repair, uninstall, logger_manager
    constants = reload(constants)
    helpers = reload(helpers)
    install = reload(install)
    repair = reload(repair)
    uninstall = reload(uninstall)
    logger_manager = reload(logger_manager)
    return constants, helpers, install, repair, uninstall, logger_manager


logger = logger_manager.LoggerManager('setup', constants.LOG_LEVEL).get_logger()


def setup():
    """
    Main setup function which renders welcome screen and based on user's preference, calls corresponding function
    """

    global constants, helpers, install, repair, uninstall, logger_manager

    logger.info('Netskope CLS v{} installer started.'.format(constants.VERSION))
    helpers.render_welcome_screen()

    preference = helpers.get_input('Enter your choice: ')

    while preference not in ['1', '2', '3', '4', '9', 'q']:
        preference = helpers.get_input('Invalid choice. Try again: (1/2/3/4/9/Q) ')

    logger.info('Choice entered for welcome screen preference is: {}'.format(preference))

    if preference == 'q':
        logger.info('Quitting the installer on user preference.')
        return

    if preference == '1':
        if helpers.is_installed(enable_printing=False):
            helpers.print_and_log(
                'It seems that Netskope CLS v{} is already installed. First, uninstall it and then try again.'.format(
                    constants.VERSION
                )
            )
            return
        helpers.render_installation_screen()
        agreement = helpers.get_input('\nDo you want to accept the agreement? (y/n): ')

        while agreement not in constants.VALID_BOOLEAN_INPUTS:
            agreement = helpers.get_input('Invalid choice. Try again (y/n): ')

        logger.info('EULA agreement preference: {}'.format(agreement))

        agreement = agreement in constants.POSITIVE_BOOLEAN_INPUTS

        if not agreement:
            helpers.print_and_log(
                'End-user license agreement acceptance is required to install Netskope CLS. Exiting the installer.')
            return

        helpers.clear()
        helpers.print_separator()
        print('Netskope CLS Configuration'.center(constants.WIDTH))
        helpers.print_separator()

        if not install.install():
            print('Check setup logs ({}) for more details.'.format(constants.SETUP_LOGS_PATH))
            return

        helpers.print_separator()
        helpers.print_and_log('Netskope CLS installed successfully.')
        helpers.print_commands()

    if preference == '2' and not repair.repair():
        print('Check setup logs ({}) for more details.'.format(constants.SETUP_LOGS_PATH))
        return

    if preference == '3':
        # if docker compose exists then take the backup and then perform upgrade
        if helpers.is_installed(enable_printing=False):
            date = repair.save_backup()
            upgrade.upgrade_with_configurations(date)
        else:
            # if CLS is not installed, just pull from git
            upgrade.upgrade_without_configurations()

    if preference == '4':
        configure_proxy.configure_proxy()

    if preference == '9' and not uninstall.uninstall():
        return


def run():
    if helpers.check_prerequisite():
        setup()
