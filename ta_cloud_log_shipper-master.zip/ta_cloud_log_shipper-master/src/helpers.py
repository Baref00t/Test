import re
import os
import copy
import shutil
import logging
import requests
import subprocess

import urllib.parse
import oyaml as yaml
from pyfiglet import Figlet
from oyaml import SafeDumper

from .constants import (
    WIDTH,
    VERSION,
    API_URL,
    LOG_LEVEL,
    CONFIG_DIR,
    STATIC_DIR,
    VALID_BOOLEAN_INPUTS,
    TEMPLATE_ENV_DIR,
    SETUP_LOGS_PATH,
    SETUP_LOGS_DIR,
    AES_KEY,
    ENV_SECURE_ATTRIBUTES,
    DOCKER_COMPOSE_SECURE_ATTRIBUTES
)
from .logger_manager import LoggerManager
from .aes_cipher import AESCipher

logger = LoggerManager('setup', LOG_LEVEL).get_logger()
aes_cipher = AESCipher(AES_KEY)

# Null values should be printed and saved as empty strings
SafeDumper.add_representer(
    type(None),
    lambda dumper, value: dumper.represent_scalar(u'tag:yaml.org,2002:null', '')
)


def repr_bool(dumper, data):
    val = 'True' if data else 'False'
    return dumper.represent_scalar(u'tag:yaml.org,2002:str', val)


SafeDumper.add_representer(
    bool,
    repr_bool
)


def clear():
    """
    Function for clearing the screen
    """
    os.system('clear')


def print_separator(length=80):
    """
    Print separator with given length
    """
    print('=' * length)


def read_yaml(file_path):
    """
    Reads given YAML file

    :param file_path: Path of the file to be read as YAML
    :returns: Dict of read YAML from given file
    :throws: FileNotFoundError, YAMLError
    """
    with open(file_path) as infile:
        return yaml.safe_load(infile)


def render_welcome_screen():
    """
    Print welcome screen on installer startup
    """
    f = Figlet(font='big')
    clear()
    print(f.renderText('Netskope  CLS'))
    print_separator()
    print('Netskope Cloud Log Shipper (v{}) Setup'.format(VERSION).center(WIDTH))
    print_separator()
    print('> Press 1 to Install')
    print('> Press 2 to Repair')
    print('> Press 3 to Upgrade')
    print('> Press 4 to Configure Proxy')
    print()
    print('> Press 9 to Uninstall')
    print('> Press Q to Quit')
    print()


def render_installation_screen():
    """
    Renders installation screen with EULA
    """
    clear()
    print_separator()
    print('End User Licence Agreement'.center(WIDTH))
    print_separator()
    subprocess.call(['less', '--prompt="Press ENTER to scroll, Press Q to exit from scroll view"',
                     os.path.join(STATIC_DIR, 'EULA.md')])
    print(read_file(os.path.join(STATIC_DIR, 'EULA.md')))
    print()
    print_separator()


def print_docker_compose(docker_compose_dict):
    """
    Prints docker compose from given dict

    :param docker_compose_dict: Docker compose dictionary to be printed
    """
    print(yaml.safe_dump(docker_compose_dict, default_flow_style=False))


def print_envs(configured_envs):
    """
    Prints given env files

    :param configured_envs: List of env file parameters to be printed
    """
    configured_envs = copy.deepcopy(configured_envs)
    for env_obj in configured_envs:
        if 'SYSLOG_CERT_FILE' in env_obj['env_obj']:
            del env_obj['env_obj']['SYSLOG_CERT_FILE']
        elif 'KEY_FILE' in env_obj['env_obj']:
            del env_obj['env_obj']['KEY_FILE']

        print_separator()
        print(str(env_obj['path']).center(WIDTH))
        print_separator()
        print(yaml.safe_dump(env_obj['env_obj'], default_flow_style=False))
        print()


def read_file(file_path):
    """
    Reads given text file

    :param file_path: The path of file to be read
    """
    with open(file_path, 'r') as eula_file:
        return eula_file.read()


def replace_mapping_file(services):
    """
    Replaces the mapping files in /etc/config/<tenant>_<plugin> dir with the mapping files in static folder

    :param services: List of services extracted from deocker-compose for existing plugins
    """
    for service_val in list(services.values()):
        if service_val['environment']['PLUGIN_TYPE'].lower() == 'syslog':
            copy_file(os.path.join(STATIC_DIR, 'valid_extensions.csv'), service_val['volumes'][0].split(':')[0])
            copy_file(os.path.join(STATIC_DIR, 'syslog_map.json'), service_val['volumes'][0].split(':')[0])
            logger.log(logging.INFO, 'Successfully replaced SYSLOG mapping file(s).')
        elif service_val['environment']['PLUGIN_TYPE'].lower() == 'cscc':
            copy_file(os.path.join(STATIC_DIR, 'cscc_map.json'), service_val['volumes'][0].split(':')[0])
            logger.log(logging.INFO, 'Successfully replaced CSCC mapping file.')
        elif service_val['environment']['PLUGIN_TYPE'].lower() == 'azure_sentinel':
            copy_file(os.path.join(STATIC_DIR, 'azure_sentinel_map.json'), service_val['volumes'][0].split(':')[0])
            logger.log(logging.INFO, 'Successfully replaced AZURE SENTINEL mapping file.')
        else:
            copy_file(os.path.join(STATIC_DIR, 'mcas_map.json'), service_val['volumes'][0].split(':')[0])
            logger.log(logging.INFO, 'Successfully replaced MCAS mapping file.')


def encrypt_obj(obj):
    """
    Encrypts the given object's secure attributes

    :param obj: Python dict containing attribute values to be encrypted
    """
    for key, value in obj.items():
        if isinstance(value, dict):
            encrypt_obj(value)
        else:
            if (
                (key in ENV_SECURE_ATTRIBUTES or
                 key in DOCKER_COMPOSE_SECURE_ATTRIBUTES) and
                value
            ):
                obj[key] = aes_cipher.encrypt(value)


def encrypt(key, value):
    """
    Encrypts the given value if the given key is one of the secure attributes

    :param key: The key corresponding to the value being encrypted
    :param value: The value to be encrypted
    :returns: The encrypted value or value as it is if not corresponding to a secure attribute
    """
    if (
        (key in ENV_SECURE_ATTRIBUTES or
         key in DOCKER_COMPOSE_SECURE_ATTRIBUTES) and
        value
    ):
        return aes_cipher.encrypt(value)
    return value


def decrypt(key, value):
    """
    Decrypts the given value if the key is one of the secure attributes

    :param key: The key whose value is to be decrypted
    :param value: The value to be decrypted
    :returns: The decrypted plain text
    """
    if (
            (key in ENV_SECURE_ATTRIBUTES or
             key in DOCKER_COMPOSE_SECURE_ATTRIBUTES) and
            value
    ):
        try:
            return aes_cipher.decrypt(value)
        except Exception:
            print_and_log('An error occurred while decrypting the value of proxy password.'
                          ' Make sure you have entered correct password using CLI.'.format(key))
            exit(0)
    return value


def decrypt_object(obj):
    """
    Drcrypts the given object's secure attributes

    :param obj: Python dict containing attribute values to be decrypted
    """
    for key, value in obj.items():
        if isinstance(value, dict):
            decrypt_object(value)
        else:
            obj[key] = decrypt(key, value)


def write_env(configured_envs):
    """
    Writes env files from given list of dictionaries

    :param configured_envs: List of env file params to be saved as env files
    """
    for env in configured_envs:
        with open(env['path'], 'w') as env_file:
            env_vars = []
            for key, val in env['env_obj'].items():
                env_vars.append('{}={}'.format(key, val if val else ''))
            env_file.write('\n'.join(env_vars))


def write_yml(file, yml_obj):
    """
    Writes yml file to a given path with given parameters dict

    :param file: Path where yml file is to be written
    :param yml_obj: Parameters to be written in yml file
    """
    with open(file, 'w') as outfile:
        yaml.safe_dump(yml_obj, outfile, default_flow_style=False)


def read_env(file_path):
    """
    Reads given ENV file

    :param file_path: Path of the file to be read as ENV
    :returns: Dict of read ENV from given file
    :throws: FileNotFoundError
    """
    result = {}
    with open(file_path) as env_file:
        env_file = env_file.read().split('\n')
        for line in env_file:
            if line:
                result[line.split('=')[0].strip()] = line.split('=', 1)[1].strip() if line.split('=', 1)[
                    1].strip() else None
    return result


def print_and_log(message, log_level=logging.INFO):
    """
    Prints and issues log with given log level for given message

    :param message: The message to be logged and printed
    :param log_level: The log level at with the log for given message is to be issued
    """
    print(message)
    logger.log(log_level, message, exc_info=log_level == logging.ERROR)


def print_commands(command='> sudo docker-compose up -d'):
    """
    Prints command for user after any action
    :param command: The command to be printed
    """
    print_separator()
    print('Netskope CLS setup logs are available at "{}".'.format(SETUP_LOGS_PATH))
    print_separator()
    print('You can start the docker using below commands:')
    print('> cd {}'.format(CONFIG_DIR))
    print('{}'.format(command))
    print()
    print('Netskope CLS logs are available at "/var/log/netskope_cls/".')
    print_separator()


def get_input(display_text, lower=True):
    """
    Gets user input by displaying given text on screen, also trims the input text and converts it to lowercase if
    required

    :param display_text: Text to be displayed on screen
    :param lower: flag which indicates whether converting input to lower case is required or not

    :returns: trimmed and lowercased (if specified) user input
    """
    if lower:
        return input(display_text).lower().strip()
    return input(display_text).strip()


def iterate_dirs(dir_path):
    """
    Iterates over dir and all subdirs of given directory path

    :param dir_path: The path of directory to be iterated
    :returns: List of all files in given dir and all its subdirs
    """
    files_list = []
    for subdir, dirs, files in os.walk(dir_path):
        files = [f for f in files if not f[0] == '.']
        dirs[:] = [d for d in dirs if not d[0] == '.' and not d == SETUP_LOGS_DIR]
        for file in files:
            files_list.append(os.path.join(subdir, file))
    return files_list


def is_installed(enable_printing=True):
    """
    Checks whether Netskope CLS is installed or not

    :returns: True if Netskope CLS is installed, False otherwise
    """

    # If configuration dir is not present
    if not os.path.isdir(CONFIG_DIR):
        if enable_printing:
            print_and_log('Configuration directory "{}" does not exists.'.format(CONFIG_DIR))
        return False

    # If docker-compose in configuration dir is not present
    if not os.path.isfile(os.path.join(CONFIG_DIR, 'docker-compose.yml')):
        if enable_printing:
            print_and_log('Docker-compose file does not exists at path: "{}".'.format(
                os.path.join(CONFIG_DIR, 'docker-compose.yml')))
        return False
    return True


def check_docker_compose_version():
    """
    Checks whether docker-compose is installed or not by checking its version

    :returns: True is case it's installed, False otherwise
    """
    process = subprocess.check_output(['docker-compose', '--version'])
    output = process.decode("utf-8")
    logger.info('Docker compose version: {}'.format(output))
    docker_compose_re = r'^docker-compose version .*?, build .*?$'
    if re.match(docker_compose_re, output):
        return True
    return False


def check_docker_version():
    """
    Checks whether docker is installed or not by checking its version

    :returns: True is case it's installed, False otherwise
    """
    process = subprocess.check_output(['docker', '--version'])
    output = process.decode("utf-8")
    logger.info('Docker version: {}'.format(output))
    docker_compose_re = r'^Docker version .*?, build .*?$'
    if re.match(docker_compose_re, output):
        return True
    return False


def copytree(src, dst, symlinks=False, ignore=None):
    """
    Copies entire directory from given source path to destination path

    :param src: Path of directory to be copied
    :param dst: Destination path where the directory is to be copied
    """
    if not os.path.exists(dst):
        os.makedirs(dst)
    for item in os.listdir(src):
        s = os.path.join(src, item)
        d = os.path.join(dst, item)
        if os.path.isdir(s):
            copytree(s, d, symlinks, ignore)
        else:
            if not os.path.exists(d) or os.stat(s).st_mtime - os.stat(d).st_mtime > 1:
                shutil.copy2(s, d)


def copy_file(source_path, dest_path):
    """
    Copies file present at given source path to given destination path

    :param source_path: Path of the file to be copied
    :param dest_path: Destination path where the given file is to be copied
    """
    try:
        shutil.copy2(source_path, dest_path)
    except Exception:
        print_and_log('An error occurred while copying file.', logging.ERROR)
        return False
    logger.info('Successfully copied file from path {} to {}'.format(source_path, dest_path))
    return True


def sanitize_input(inp):
    """
    Sanitizes the user input values to its proper data type

    :param inp: User input to be sanitized
    :returns: User input converted in proper data type
    """
    try:
        # Convert to int if it is integer
        return int(inp)
    except ValueError:
        return inp


def validate_tenant(tenant):
    """
    Validates the given tenant name by making API call to that tenant
    """
    print_and_log('Validating the tenant: "{}.goskope.com"...'.format(tenant))
    try:
        proxy = {}
        proxy_env = get_proxy_env()

        if proxy_env['ENABLE_PROXY'] in ['y', 'yes']:
            if proxy_env['AUTHENTICATED_PROXY'] in ['n', 'no']:
                proxy['https'] = '{}://{}:{}'.format(
                    proxy_env['PROXY_SCHEME'],
                    proxy_env['PROXY_SERVER'],
                    proxy_env['PROXY_PORT']
                )
                proxy['http'] = '{}://{}:{}'.format(
                    proxy_env['PROXY_SCHEME'],
                    proxy_env['PROXY_SERVER'],
                    proxy_env['PROXY_PORT']
                )
            else:
                # Decrypt the proxy password before using proxy for validation
                decrypt_object(proxy_env)

                proxy['https'] = '{}://{}:{}@{}:{}/'.format(
                    proxy_env['PROXY_SCHEME'],
                    urllib.parse.quote(proxy_env['USERNAME'], safe=''),
                    urllib.parse.quote(proxy_env['PASSWORD'], safe=''),
                    proxy_env['PROXY_SERVER'],
                    proxy_env['PROXY_PORT']
                )
                proxy['http'] = '{}://{}:{}@{}:{}/'.format(
                    proxy_env['PROXY_SCHEME'],
                    urllib.parse.quote(proxy_env['USERNAME'], safe=''),
                    urllib.parse.quote(proxy_env['PASSWORD'], safe=''),
                    proxy_env['PROXY_SERVER'],
                    proxy_env['PROXY_PORT']
                )

        requests.get(API_URL.format(tenant), proxies=proxy)
    except Exception as err:
        logger.exception('Error occurred while validating tenant name. Error: {}'.format(err))
        return False
    return True


def value_check(value, message):
    """
    Takes the input from user until it's valid
    :param value: The input value to be validated
    :param message: The message to be printed for user to take input

    :returns: The valid value got from user
    """
    while str(value).lower() not in VALID_BOOLEAN_INPUTS:
        value = get_input(message)
    return value


def print_for_review(docker_compose_dict, configured_envs):
    """
    Prints the configured docker compose and env files for user review before saving

    :param docker_compose_dict: Docker compose params to be printed
    :param configured_envs: List of configured env files to be printed
    """
    clear()
    print_separator()
    print('Review configured values'.center(WIDTH))
    print_separator()

    print()

    print_separator()
    print('Docker Compose'.center(WIDTH))
    print_separator()
    print_docker_compose(docker_compose_dict)
    print_envs(configured_envs)
    print_separator()


def check_prerequisite():
    """
    Checks for docker and docker compose prerequisite

    :returns: True in case of prerequisite satisfied, False otherwise
    """
    if not check_docker_compose_version():
        print_and_log(
            'Could not find Docker Compose. Install Docker Compose manually and try again. Reference for '
            'installation: https://docs.docker.com/compose/install/')
        return False
    elif not check_docker_version():
        print_and_log(
            'Could not find Docker Engine. Install Docker manually and try again. Reference for installation: '
            'https://docs.docker.com/engine/install/')
        return False

    return True


def print_and_log_error(err):
    """
    Both prints and logs the error message
    :param err: The error message to be printed and logged
    """
    logger.error('An error occurred while upgrading Netskope CLS. Error {}'.format(err))
    print('Check setup logs ({}) for more details.'.format(SETUP_LOGS_PATH))


def copy_proxy_after_install():
    """
    Copies the default proxy env file after installation if proxy
    is not already configured
    """
    proxy_env = get_proxy_env()
    if not os.path.isfile(os.path.join(CONFIG_DIR, 'env', 'common_config.env')):
        result = []
        proxy_configured_env = {
            'path': os.path.join(CONFIG_DIR, 'env', '{}.env'.format('common_config')),
            'env_obj': proxy_env
        }
        result.append(proxy_configured_env)
        write_env(result)


def get_proxy_env():
    """
    Read the proxy env file. If any error occurs, log and exit.
    """
    if os.path.isfile(os.path.join(CONFIG_DIR, 'env', 'common_config.env')):
        return read_env(os.path.join(CONFIG_DIR, 'env', 'common_config.env'))
    else:
        try:
            return read_env(os.path.join(TEMPLATE_ENV_DIR, 'common_config.env'))
        except FileNotFoundError:
            print_and_log('Could not find env template file "{}". Pull fresh repository from git and try'
                          ' again.'.format('common_config'))
            exit(1)
        except Exception as err:
            print_and_log(
                'An error occurred while reading env template file "{}". Pull fresh repository from git and try '
                'again. Error: {}'.format('common_config', err))
            exit(1)
