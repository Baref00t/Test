import os
import logging
import logging.handlers

from .constants import LOG_BASE_DIR as BASE_DIR, MAX_BYTES_PER_LOG_FILE, LOG_BACKUP_COUNT, SETUP_LOGS_DIR


class LoggerManager:

    def __init__(self, name, log_level=None):
        """ Constructor.

        Creates logger file with given file name and log level.

        :param name: Name of log file
        :param log_level: Log level
        """
        self.name = name
        self.log_level = log_level

    def get_logger(self):
        """
        Creates logger file with given file name and log level.

        :returns: newly created logger object for logging purpose
        """

        base_dir = os.path.join(BASE_DIR, SETUP_LOGS_DIR)
        if not os.path.isdir(base_dir):
            os.makedirs(base_dir)
        logfile = os.path.join(base_dir, '{}.log'.format(self.name))
        self.name = logfile

        # log file will be stored at src/logs directory
        logger = logging.getLogger(self.name)
        logger.propagate = False
        logger.setLevel(self.log_level)

        handler_exists = any([True for h in logger.handlers
                              if h.baseFilename == self.name])

        # Rotating loggers if file size exceeds threshold of ~10MB
        if not handler_exists:
            file_handler = logging.handlers.RotatingFileHandler(self.name, mode='a',
                                                                maxBytes=MAX_BYTES_PER_LOG_FILE,
                                                                backupCount=LOG_BACKUP_COUNT)
            fmt_str = '[ %(asctime)s ] - %(levelname)s - %(thread)d - %(module)s - %(funcName)s - %(message)s'
            formatter = logging.Formatter(fmt_str)
            file_handler.setFormatter(formatter)
            logger.addHandler(file_handler)
            file_handler.setLevel(self.log_level)

        return logger
