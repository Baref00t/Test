"""Common helper functions for actions like install, repair, upgrade and uninstall"""

import os
import re
import copy
import docker
import logging
import subprocess

from .. import helpers
from ..helpers import (
    clear,
    encrypt_obj,
    read_env,
    write_env,
    write_yml,
    get_input,
    read_yaml,
    copy_file,
    value_check,
    is_installed,
    print_and_log,
    print_commands,
    sanitize_input,
    validate_tenant,
    print_separator,
    print_and_log_error
)
from ..constants import (
    WIDTH,
    MCAS_EVENT_TYPES,
    PLUGINS,
    PLUGIN_MCAS,
    TOOLTIPS,
    BKP_PATH,
    LOG_LEVEL,
    STATIC_DIR,
    CONFIG_DIR,
    SETUP_MODES,
    TEMPLATE_DIR,
    ENV_TEMPLATE,
    AVAILABLE_VALS,
    TEMPLATE_ENV_DIR,
    VALID_BOOLEAN_INPUTS,
    POSITIVE_BOOLEAN_INPUTS,
    FIELD_EXCLUDED_FROM_LOGS,
    TEMPLATE_DOCKER_COMPOSE_PATH
)
from ..logger_manager import LoggerManager

logger = LoggerManager('setup', LOG_LEVEL).get_logger()

# Read all env files and docker compose templates. If any error occurs then log and exit.
for env_file in os.listdir(TEMPLATE_ENV_DIR):
    try:
        plugin_name = env_file.split('.')[0]
        ENV_TEMPLATE[plugin_name] = read_env(os.path.join(TEMPLATE_ENV_DIR, env_file))
    except FileNotFoundError:
        print_and_log('Could not find env template file "{}". Pull fresh repository from git and try'
                      ' again.'.format(env_file))
        exit(1)
    except Exception as err:
        print_and_log('An error occurred while reading env template file "{}". Pull fresh repository from git and try '
                      'again. Error: {}'.format(env_file, err))
        exit(1)

try:
    DOCKER_COMPOSE_TEMPLATE = read_yaml(TEMPLATE_DOCKER_COMPOSE_PATH)
except FileNotFoundError:
    print_and_log('Could not find docker-compose template file "docker-compose.yml". Pull fresh repository from git '
                  'and try again.')
    exit(1)
except Exception as err:
    print_and_log('An error occurred while reading docker-compose template file. Pull fresh repository from git and '
                  'try again. Error: {}'.format(err))
    exit(1)


def validate_mapping_file_path(input):
    """
    Validates the path of given mapping file
    """
    while not input or not os.path.isfile(input):
        logger.info('Invalid path provided for mapping file')
        input = get_input('Invalid path provided. Try again: ', lower=False)
    return input


def configure_env(plugin_type, tenant_name):
    """
    Configures env file by asking user input for configuration parameters

    :param plugin_type: type of plugin for which env file is being configured
    :param tenant_name: Name of tenant for which the env file is being configured
    :returns: dict containing configured env params dict, it's path and whether the configuration is successful or not
    """
    result = {
        'success': False,
        'conf': {
            'env_path': '',
            'env': {}
        }
    }

    try:
        # Env file name would be in format: <tenant_name>_<plugin_type>.env
        env_path = os.path.join(CONFIG_DIR, 'env', '{}_{}.env'.format(tenant_name, plugin_type))
        env = copy.deepcopy(ENV_TEMPLATE[plugin_type])

        for key, val in env.items():
            # Don't ask for cert file if selected protocol is not TLS
            if key == 'SYSLOG_CERT_FILE' and 'SYSLOG_PROTOCOL' in env and str(env['SYSLOG_PROTOCOL']).lower() != 'tls':
                continue

            # Don't ask for cert file and key file names here.
            if key in ['SYSLOG_CERT_FILE', 'KEY_FILE']:
                continue

            if key in TOOLTIPS:
                print('Note: ' + TOOLTIPS[key])
            if key in AVAILABLE_VALS:
                inp = get_input(
                    'Enter value for {} (default: {} | available: {}): '.format(key, val if val else '<empty>',
                                                                                ','.join(
                                                                                    list(map(str,
                                                                                             AVAILABLE_VALS[key])))),
                    lower=False)

            elif key in ['SYSLOG_MAP', 'CSCC_MAP', 'AZURE_SENTINEL_MAP', 'MCAS_MAP']:
                inp = get_input('Enter value for {} (default: {}): '.format(key, val if val else '<empty>'),
                                lower=False)
                if inp:
                    inp = validate_mapping_file_path(inp)

            else:
                inp = get_input('Enter value for {} (default: {}): '.format(key, val if val else '<empty>'),
                                lower=False)

            if inp.lower() == 'none':
                env[key] = None
                print()
                continue
            if inp:
                env[key] = sanitize_input(inp)
            elif val:
                env[key] = val
            else:
                env[key] = None

            print()

    except Exception as err:
        print_and_log('An error occurred while configuring env file for {} plugin. Error: {}'.format(plugin_type, err),
                      logging.ERROR)
        return result

    result['success'] = True
    result['conf']['env_path'] = env_path
    result['conf']['env'] = env
    encrypt_obj(result)
    return result


def validate(key, value, message):
    """
    Checks whether the user input is empty or not. It keeps asking until the valid value is provided

    :param key: The configuration key
    :param value: the parameter being validated
    :param message: The display message in case of invalid input
    :returns: The valid input provided by user
    """
    while True:
        if value and str(value).strip():
            if key == 'TENANT_NAME':
                if validate_tenant(str(value)):
                    return value
            elif key == 'PLUGIN_TYPE':
                if str(value).lower() in [plugin.lower() for plugin in PLUGINS]:
                    return value
            elif key == 'PROXY_SCHEME':
                if str(value).lower() in [scheme.lower() for scheme in AVAILABLE_VALS['PROXY_SCHEME']]:
                    return str(value).lower()
            if key in ['ENABLE_PROXY', 'AUTHENTICATED_PROXY', 'ENABLE_DEDUPLICATION']:
                value = value_check(value, message)
                value = str(value).lower()
                return value
        value = get_input(message)


def validate_docker_config(key, value):
    """
    Validates the configured plugin type and tenant name.

    :param key: Docker compose key being validated.
    :param value: The configured value of the given key being validated
    :returns: Updated value in case of invalid configuration, otherwise returns the same value without any changes
    """
    if key == 'PLUGIN_TYPE':
        value = validate(key, value, 'Found an invalid value for plugin type. Available plugin types are {}. '
                                     'Try again: '.format(PLUGINS))

    elif key == 'TENANT_NAME':
        value = validate(key, value, 'Found an invalid value for tenant name or tenant is not reachable. Try again: ')

    elif key == 'PROXY_SCHEME':
        value = validate(key, value, 'Found an invalid value for proxy scheme. Try again: ')

    if key in ['ENABLE_PROXY', 'AUTHENTICATED_PROXY', 'ENABLE_DEDUPLICATION']:
        value = validate(key, value, 'Invalid Choice. Try again (y/n): ')

    return value


def add_new_service(setup_mode):
    """
    Configures new docker-compose service by asking configuration parameters to user

    :returns: Configured values in docker-compose and corresponding env file with a status flag indicating whether the
    configuration was successful or not
    """
    result = {
        'success': False,
        'conf': {
            'docker_compose_dict': {},
            'configured_envs': []
        }
    }
    has_duplicate = False

    while True:
        docker_compose = copy.deepcopy(DOCKER_COMPOSE_TEMPLATE)

        print(
            'Enter new values to override default values. Press ENTER to keep the default values. Enter "None" to set '
            'empty value.')
        print()
        print('A combination of tenant name & plugin type should be unique across all integrations.')
        print()
        service = next(iter(docker_compose['services']))

        for key, val in docker_compose['services'][service]['environment'].items():
            # Don't ask for ssl verification as it will be advanced configuration
            if key == 'VERIFY_SSL':
                continue

            if key in ['ALERT_TYPE', 'ALERT_QUERY'] and docker_compose['services'][service]['environment']['PLUGIN_TYPE'].lower() == PLUGIN_MCAS:
                docker_compose['services'][service]['environment'][key] = None
                continue

            # If deduplication is enabled then don't ask for number of threads
            if key == 'N_THREADS' and str(docker_compose['services'][service]['environment'][
                                              'ENABLE_DEDUPLICATION']).lower() in POSITIVE_BOOLEAN_INPUTS:
                continue

            if key in TOOLTIPS:
                print('Note: ' + TOOLTIPS[key])
            if key == 'EVENT_TYPE' and docker_compose['services'][service]['environment']['PLUGIN_TYPE'].lower() == PLUGIN_MCAS:
                val = ','.join(MCAS_EVENT_TYPES)
            if key in AVAILABLE_VALS:
                inp = get_input(
                    'Enter value for {} (default: {} | available: {}): '.format(key, val if val else '<empty>',
                                                                                ','.join(
                                                                                    list(map(str,
                                                                                             AVAILABLE_VALS[key])))),
                    lower=False)
            else:
                inp = get_input('Enter value for {} (default: {}): '.format(key, val if val else '<empty>'),
                                lower=False)

            if inp.lower() == 'none':
                docker_compose['services'][service]['environment'][key] = None
                docker_compose['services'][service]['environment'][key] = \
                    validate_docker_config(key, docker_compose['services'][service]['environment'][key])
                if docker_compose['services'][service]['environment'][key]:
                    logger.info('Value entered for configuration key "{}": {}'.format(
                        key,
                        docker_compose['services'][service]['environment'][key])
                    )
                else:
                    logger.info('Empty value selected for configuration key "{}"'.format(key))
                print()
                continue

            is_default = False
            if inp:
                docker_compose['services'][service]['environment'][key] = sanitize_input(inp)
            elif val:
                if key not in FIELD_EXCLUDED_FROM_LOGS:
                    logger.info('Default value "{}" selected for configuration key "{}"'.format(val, key))
                    is_default = True
                docker_compose['services'][service]['environment'][key] = val
            else:
                docker_compose['services'][service]['environment'][key] = None

            docker_compose['services'][service]['environment'][key] = \
                validate_docker_config(key, docker_compose['services'][service]['environment'][key])

            inp_value = docker_compose['services'][service]['environment'][key]
            if key not in FIELD_EXCLUDED_FROM_LOGS and not is_default:
                if inp_value:
                    logger.info('Value entered for configuration key "{}": {}'.format(key, inp_value))
                else:
                    logger.info('Empty value selected for configuration key "{}"'.format(key))

            print()

        plugin_type = docker_compose['services'][service]['environment']['PLUGIN_TYPE']
        tenant_name = docker_compose['services'][service]['environment']['TENANT_NAME']
        plugin_type = plugin_type.lower()

        # Format volumes stanza of docker-compose
        docker_compose['services'][service]['env_file'][0] = os.path.join('env',
                                                                          '{}_{}.env'.format(tenant_name, plugin_type))
        for index, volume in enumerate(docker_compose['services'][service]['volumes']):
            docker_compose['services'][service]['volumes'][index] = re.sub(r'<tenant_name>',
                                                                           '{}_{}'.format(tenant_name, plugin_type),
                                                                           docker_compose['services'][service][
                                                                               'volumes'][
                                                                               index])

        service_key = re.sub(r'<tenant_name>', '{}_{}'.format(tenant_name, plugin_type), service)

        if (
                'services' in result['conf']['docker_compose_dict'] and
                service_key in result['conf']['docker_compose_dict']['services']
        ):
            has_duplicate = True

        docker_compose['services'][service_key] = docker_compose['services'].pop(service)

        if 'services' in result['conf']['docker_compose_dict']:
            result['conf']['docker_compose_dict']['services'][service_key] = docker_compose['services'][service_key]
        else:
            result['conf']['docker_compose_dict'] = copy.deepcopy(docker_compose)

        plugin_type = docker_compose['services'][service_key]['environment']['PLUGIN_TYPE'].lower()
        print_separator()
        print('Enter configuration values for {}_{}.env'.format(tenant_name, plugin_type))
        print_separator()

        # Configure corresponding env file
        env_conf_result = configure_env(plugin_type, tenant_name)

        if has_duplicate:
            print()
            print_separator()
            print_and_log('A combination of tenant name & plugin type should be unique across all integration.')
            print_separator()
            return result

        # In case of repair, check for duplication from configured docker compose file
        if setup_mode == SETUP_MODES['REPAIR'] and is_installed(enable_printing=False):
            # Check for duplication of services
            existing_docker_compose = read_yaml(os.path.join(CONFIG_DIR, 'docker-compose.yml'))

            for conf_service in result['conf']['docker_compose_dict']['services']:
                if conf_service in existing_docker_compose['services']:
                    print()
                    print_separator()
                    print_and_log('A combination of tenant name & plugin type should be unique across all integration.')
                    print_separator()
                    return result

        if not env_conf_result['success']:
            return result

        result['conf']['configured_envs'].append({
            'path': env_conf_result['conf']['env_path'],
            'env_obj': env_conf_result['conf']['env']
        })

        print_separator()
        pref = get_input('Do you want to configure another integration? (y/n): ')
        while pref not in VALID_BOOLEAN_INPUTS:
            pref = get_input('Invalid choice. Try again (y/n): ')

        pref = pref in POSITIVE_BOOLEAN_INPUTS

        if not pref:
            break
        clear()
        logger.info('Opted for creating another integration.')

    result['success'] = True
    encrypt_obj(result)
    return result


def get_volumes(docker_compose_path):
    """
    Fetches mapped volumes from configured docker compose file

    :returns: List of mapped volumes
    """
    volumes = []
    docker_compose = read_yaml(docker_compose_path)
    for service in docker_compose['services']:
        for volume in docker_compose['services'][service]['volumes'][:2]:
            volume_path = volume[:volume.index(":")]
            folder_path = volume_path[:volume_path.rindex('/')]
            volumes.append(folder_path)
    return volumes


def create_config_dir_structure(plugin_type, tenant_name, volumes, syslog_protocol, path):
    """
    Creates directory structure as per the volume mappings in docker compose file. Also copies the require configuration
    files to provided paths in docker-compose

    :param path: File path being copied in creation on directory structure
    :param syslog_protocol: Syslog protocol for which directory structure is being created
    :param tenant_name: The name of tenant for which directory structure is being created
    :param plugin_type: Type of plugin for which directory structure is being created
    :param volumes: The volumes mapped in docker-compose file
    """
    result = {
        'success': False,
        'copied_file': '',
        'key_name': ''
    }
    try:
        # Create dir structure
        for volume in volumes:
            returncode = subprocess.call(['mkdir -p {}'.format(volume.split(':')[0])], shell=True)
            if returncode != 0:
                print_and_log(
                    'An error occurred while creating directory structure for "{}" plugin'.format(plugin_type),
                    logging.ERROR)
                return result

        # Copy the required configurations to config dir
        if plugin_type.lower() == 'cscc':
            # Ask for key file and copy it
            if not copy_file(path, volumes[0].split(':')[0]):
                return result

            print_separator()
            print('CSCC Plugin requires Google Service Account Key configuration'.center(WIDTH))
            print_separator()

            # Ask for Google Service account key file path
            key_file = get_input('Enter the path of Google Service account key file for '
                                 'tenant "{}": '.format(tenant_name), lower=False)
            logger.info('Entered path for Google Service account key file: {}'.format(key_file))
            while not key_file or not os.path.exists(key_file):
                logger.info('Invalid path provided for Google Service account key file: {}'.format(key_file))
                key_file = get_input('Invalid path provided. Try again: ', lower=False)

            result['copied_file'] = key_file
            result['key_name'] = 'KEY_FILE'
            if not copy_file(key_file, volumes[0].split(':')[0]):
                return result
        elif plugin_type.lower() == 'syslog':

            if not (copy_file(path, volumes[0].split(':')[0]) and
                    copy_file(os.path.join(STATIC_DIR, 'valid_extensions.csv'), volumes[0].split(':')[0])):
                return result

            if str(syslog_protocol).lower() == 'tls':
                # In case TLS protocol, certificate file is required.
                print_separator()
                print('Syslog Plugin with TLS protocol requires a certificate file'.center(WIDTH))
                print_separator()

                # Ask for certificate file path
                cert_file = get_input('Enter the path of certificate file for '
                                      'tenant "{}": '.format(tenant_name), lower=False)
                logger.info('Entered path for certificate file: {}'.format(cert_file))

                while not cert_file or not os.path.exists(cert_file):
                    logger.info('Invalid path provided for certificate file: {}'.format(cert_file))
                    cert_file = get_input('Invalid path provided. Try again: ', lower=False)

                result['copied_file'] = cert_file
                result['key_name'] = 'SYSLOG_CERT_FILE'
                if not copy_file(cert_file, volumes[0].split(':')[0]):
                    return result
        elif plugin_type.lower() == 'azure_sentinel':
            if not copy_file(path, volumes[0].split(':')[0]):
                return result
        elif plugin_type.lower() == PLUGIN_MCAS:
            if not (copy_file(path, volumes[0].split(':')[0]) and copy_file(
                    os.path.join(STATIC_DIR, 'valid_extensions.csv'), volumes[0].split(':')[0])):
                return result
        else:
            print_and_log(
                'Found an invalid plugin type: {}. available plugin types are {}. Re-run the installation with '
                'correct plugin types.'.format(plugin_type, PLUGINS))
            return result

    except Exception as err:
        print_and_log('An error occurred while creating directory structure for configuration. '
                      'Error: {}'.format(err), logging.ERROR)
        return result

    result['success'] = True
    return result


def get_configured_services():
    """
    Fetches the list of configured services from docker compose

    :returns: The list of configured services
    """
    configured_services = read_yaml(os.path.join(CONFIG_DIR, 'docker-compose.yml'))['services']
    return list(configured_services.keys())


def get_running_cls_containers(service_key):
    """
    Fetches the running CLS docker containers

    :returns: List of running docker containers specific to CLS
    """
    cls_containers = []
    try:
        docker_client = docker.from_env()
        running_containers = docker_client.containers.list()

        for container in running_containers:
            container_id = container.id
            container = docker_client.containers.get(container_id)
            if 'com.docker.compose.service' in container.attrs['Config']['Labels']:
                service = container.attrs['Config']['Labels']['com.docker.compose.service']

                # If specific service not provided, get all CLS specific docker containers
                if not service_key:
                    services = get_configured_services()
                    if service in services:
                        cls_containers.append(container)
                else:  # In case of specific service is specified, fetch only the specific docker container
                    if service_key == service:
                        cls_containers.append(container)

    except Exception as err:
        print_and_log('An error occurred while retrieving list of running docker containers for CLS. Error: '
                      '{}'.format(err))
        exit(1)
    return cls_containers


def is_container_running(service=None):
    """
    Checks whether any docker containers are running on host machine

    :returns: True in case of any running docker containers, False otherwise
    """
    return True if len(get_running_cls_containers(service)) > 0 else False


def stop_containers(service=None):
    """
    Stops running Netskope CLS docker containers (if any)

    :returns: True in case of success, False otherwise
    """
    try:
        cls_containers = get_running_cls_containers(service)
        for container in cls_containers:
            container.stop()

        if service:
            print_and_log('Stopped CLS docker container for integration "{}" successfully.'.format(service))
        else:
            print_and_log('Stopped all the running CLS docker containers successfully.')
    except Exception as err:
        print_and_log('An error occurred while stopping the running docker containers. Error: {}'.format(err),
                      logging.ERROR)
        return False
    return True


def check_and_stop_multiple_containers(services):
    """
    Check for running CLS docker containers for given services
    and stop them after user approval (if any)
    """
    running_containers = []
    for service in set(services):
        if is_container_running(service):
            running_containers.append(service)

    if not running_containers:
        return True
    else:
        print_separator()
        print(
            'In order to reflect the latest changes (if any), the following docker '
            'container(s) must be stopped and started again:')
        for index, container in enumerate(running_containers):
            print('> {}. {}'.format(index + 1, container))
        agreement = get_input('Do you want to stop the running docker container(s)? (y/n): ')
    while agreement not in VALID_BOOLEAN_INPUTS:
        agreement = get_input('Invalid choice. Try again (y/n): ')

    agreement = agreement in POSITIVE_BOOLEAN_INPUTS

    if agreement:
        for container in running_containers:
            if not stop_containers(container):
                return False
    else:
        print(
            'In order to reflect the latest changes (if any) later on, stop and restart the running container(s) with '
            'following commands.'
        )
    return True


def check_and_stop_containers(service=None):
    """
    Check for running CLS docker containers and stop after user approval (if any)
    """
    if is_container_running(service):
        if service:
            agreement = get_input('CLS docker container for integration "{}" is running. Do you want to stop the '
                                  'running docker container? (y/n): '.format(service))
        else:
            agreement = get_input('CLS docker container(s) is/are running. Do you want to stop the running docker '
                                  'container(s)? (y/n): ')

        while agreement not in VALID_BOOLEAN_INPUTS:
            agreement = get_input('Invalid choice. Try again (y/n): ')

        agreement = agreement in POSITIVE_BOOLEAN_INPUTS

        if agreement:
            if not stop_containers(service):
                return False
        else:
            print_and_log('Aborting the repair as user has denied to stop running docker container(s).')
            return False
    return True


def get_syslog_protocol(env_path, configured_envs):
    """
    Fetches the Syslog protocol from given syslog env file
    :param env_path: The path of env file
    :param configured_envs: Dict of configured env files
    :return: Syslog protocol
    """
    env_path = os.path.join(CONFIG_DIR, env_path)
    for env_obj in configured_envs:
        if env_obj['path'] == env_path and 'SYSLOG_PROTOCOL' in env_obj['env_obj']:
            return env_obj['env_obj']['SYSLOG_PROTOCOL']
    return None


def compare_template(read_old_template, read_updated_template):
    """
    Generic method to compare templates of docker-compose and env files

    :param read_old_template: Older template before pulling from github
    :param read_updated_template The latest template pulled from github
    :returns: the python dict containing new configuration parameters
    """
    config_obj = {}
    for key, val in read_updated_template.items():

        if key not in read_old_template:
            config_obj[key] = val
    return config_obj


def check_for_env_updates(tenants, date):
    """
    It checks if there are any changes in env file

    :param tenants: The list containing tenants present in configured docker-compose
    :param date: The backup date-time

    :returns: The list of plugins whose env file is changed
    """
    change_envs = []
    try:
        for env in PLUGINS:
            for tenant in tenants:
                if os.path.isfile(os.path.join(BKP_PATH, 'cls_backup_{}'.format(date.strftime("%Y-%m-%dT%Hh%Mm%Ss")),
                                               '{}_{}.env'.format(tenant, env.lower()))):

                    read_template_env = read_env(
                        os.path.join(BKP_PATH, 'cls_backup_{}'.format(date.strftime("%Y-%m-%dT%Hh%Mm%Ss")),
                                     '{}_{}.env'.format(tenant, env.lower())))
                    len_template = len(read_template_env)

                    read_updated_env = read_env(os.path.join(TEMPLATE_DIR, 'env', '{}.env'.format(env.lower())))
                    len_updated_template = len(read_updated_env)
                    if len_template < len_updated_template:
                        change_envs.append(env)

    except Exception as err:
        print_and_log_error(err)
    return change_envs


def git_pull():
    """
    Performs pull from github in order to fetch latest changes

    :returns: True in case of success, False otherwise
    """
    try:
        subprocess.check_output(['git', 'pull'])
    except subprocess.CalledProcessError as e:
        print()
        print_and_log('Error occured while fetching the latest changes from GitHub. Try again. Error: {}'.format(e))
        print()
        return False
    return True


def take_input(key, val):
    """
    Generic method to take input of the newly added configuration parameters for docker-compose/env file
    :param key: The configuration key for which the input is to be taken
    :param val: Default value of the given key (if available)
    """

    # First print the tooltip
    if key in TOOLTIPS:
        print('Note: ' + TOOLTIPS[key])

    if key in AVAILABLE_VALS:
        inp = get_input('Enter value for {} (default: {} | available: {}): '.format(
            key,
            val if val else '<empty>',
            ','.join(list(map(str, AVAILABLE_VALS[key])))
        ),
            lower=False
        )
    else:
        inp = get_input('Enter value for {} (default: {}): '.format(key, val if val else '<empty>'), lower=False)

    return inp


def take_env_input(config_obj):
    """
    Takes input for the configuration parameters of env file

    :params config_obj: A dict of newly added configuration parameter(s) in env file
    """

    for key, val in config_obj.items():

        inp = take_input(key, val)

        if inp.lower() == 'none':
            config_obj[key] = None
            config_obj[key] = validate_docker_config(key, config_obj[key])
            print()
            continue

        if inp:
            config_obj[key] = sanitize_input(inp)
        elif val:
            config_obj[key] = val
        else:
            config_obj[key] = None

        print()
        config_obj[key] = validate_docker_config(key, config_obj[key])

    return config_obj


def edit_env_file(tenant, plugin, config_obj, date):
    """
    Takes input of newly added configuration parameters of env file

    :param tenant: Name of the tenant
    :param plugin: Plugin type
    :param config_obj: dict containing newly added parameter(s)
    """
    try:
        env_parameter = read_env(os.path.join(BKP_PATH, 'cls_backup_{}'.format(date.strftime("%Y-%m-%dT%Hh%Mm%Ss")),
                                              '{}_{}.env'.format(tenant, plugin)))
        print_separator()
        print('Enter value(s) for newly added configuration parameter(s) for file "{}_{}.env"'.format(tenant, plugin))
        print_separator()

        config_obj = take_env_input(config_obj)
        encrypt_obj(config_obj)
        env_parameter.update(config_obj)
        return env_parameter
    except Exception as err:
        print_and_log_error(err)


def update_env_params(env_params, env, tenant, date):
    """
    Updates the given env file's configuration parameters

    :param env_params: newly added env parameters after git pull
    :param env: env file, in which parameters has changed
    :param date: The backup date time
    """

    services = read_yaml(
        os.path.join(BKP_PATH, 'cls_backup_{}'.format(date.strftime("%Y-%m-%dT%Hh%Mm%Ss")), 'docker-compose.yml'))[
        'services']

    for service_key, service_val in services.items():
        if (
                service_val['environment']['PLUGIN_TYPE'] == env.lower() and
                service_val['environment']['TENANT_NAME'] == tenant
        ):
            # take input and update in respective env
            config_obj = edit_env_file(service_val['environment']['TENANT_NAME'],
                                       service_val['environment']['PLUGIN_TYPE'], env_params, date)
            edited_envs = []
            try:
                env_file = os.path.join(CONFIG_DIR, service_val['env_file'][0])
            except FileNotFoundError as err:
                print_and_log(err)
            edited_envs.append({
                'path': env_file,
                'env_obj': config_obj
            })

            # write changes in respective env
            write_env(edited_envs)


def upgrade_env(env, tenant, date):
    """
    It upgrades the changed env files with new configuration values

    :param env: The env file which changes
    :param tenant: The tenant whose env has changed
    :param date: The backup date time
    """
    try:
        if os.path.isfile(os.path.join(TEMPLATE_DIR, 'env', '{}.env'.format(env.lower()))):
            read_template_env = read_env(
                os.path.join(BKP_PATH, 'cls_backup_{}'.format(date.strftime("%Y-%m-%dT%Hh%Mm%Ss")),
                             '{}_{}.env'.format(tenant, env.lower())))
            len_template = len(read_template_env)

            read_updated_env = read_env(os.path.join(TEMPLATE_DIR, 'env', '{}.env'.format(env.lower())))
            len_updated_template = len(read_updated_env)

            changes_in_env = compare_template(read_template_env, read_updated_env)

            # If there are changes, take input for those configurations
            if len_template < len_updated_template:
                update_env_params(changes_in_env, env, tenant, date)

    except Exception as err:
        print_and_log_error(err)


def upgrade_image(service_val, updated_image):
    """
    It updates the image in docker-compose

    :param service_val: The name of the configured service
    :param updated_image: The name of the latest docker image
    """

    if updated_image != service_val['image']:
        service_val['image'] = updated_image
    return service_val


def get_docker_input(config_obj, service_key):
    """
    It takes input of the newly added docker-compose parameters
    :param config_obj: dict of newly added docker-compose parameters
    :param service_key: Name of the service being upgraded
    """

    if bool(config_obj):
        print_separator()
        print('Enter value(s) for newly added configurations parameters for integration "{}"'.format(service_key))
        print_separator()

    for key, val in config_obj.items():
        inp = take_input(key, val)

        if inp.lower() == 'none':
            config_obj[key] = None
            config_obj[key] = validate_docker_config(key, config_obj[key])
            print()
            continue

        if inp:
            if key not in FIELD_EXCLUDED_FROM_LOGS:
                logger.info('Entered value "{}" for configuration key "{}"'.format(inp, key))
            config_obj[key] = sanitize_input(inp)
        elif val:
            if key not in FIELD_EXCLUDED_FROM_LOGS:
                logger.info('Existing value "{}" selected for configuration key "{}"'.format(val, key))
            config_obj[key] = val
        else:
            logger.info('Empty value selected for configuration key "{}"'.format(key))
            config_obj[key] = None
        print()
        config_obj[key] = validate_docker_config(key, config_obj[key])

    encrypt_obj(config_obj)
    return config_obj


def upgrade_docker_compose(config_obj, services, tenants, date, updated_image):
    """
    Upgrades docker-compose with newly added configuration parameters

    :param date: The date time of back up
    :param config_obj: dict of newly added docker-compose parameter after git pull
    :param services: All services present in configured docker-compose
    :param tenants: List containing configured tenants docker-compose
    :param updated_image: The latest image after git pull
    """

    real_config_obj = copy.deepcopy(config_obj)
    for service_key, service_val in services.items():
        config_obj = copy.deepcopy(real_config_obj)
        service_val = upgrade_image(service_val, updated_image)
        print()
        config_obj = get_docker_input(config_obj, service_key)

        service_val['environment'].update(config_obj)

        # Change in envs is list contain name of env that are changed
        changes_in_envs = check_for_env_updates(tenants, date)
        if service_val['environment']['PLUGIN_TYPE'].upper() in changes_in_envs:

            if len(changes_in_envs) != 0:
                upgrade_env(service_val['environment']['PLUGIN_TYPE'].upper(),
                            service_val['environment']['TENANT_NAME'], date)

        edited_docker_compose = copy.deepcopy(read_yaml(TEMPLATE_DOCKER_COMPOSE_PATH))
    edited_docker_compose['services'] = services

    return edited_docker_compose


def read_latest_docker_template(len_template):
    """
    Reads the latest docker-compose template
    """
    print(
        'Netskope CLS successfully upgraded with the latest changes. Now you can install CLS in order to run '
        'it with the latest changes.')
    print_separator()
    exit(0)


def check_python_version():
    """
    Checks whether python3 is available or only python

    :returns: True is case python3, False otherwise
    """
    try:
        process = subprocess.check_output(['python3', '--version'])
        output = process.decode("utf-8")
        logger.info('Python version: {}'.format(output))
        pip_version = r'^Python .*?$'
        if re.match(pip_version, output):
            return True
        return False
    except Exception:
        return False


def install_dependencies():
    """
    Installs the latest dependencies from requirements.txt after upgrade

    :returns: True in case of success, False otherwise
    """
    try:
        print_and_log('Installing Python dependencies...')
        if check_python_version():
            subprocess.check_output(['python3', '-m' 'pip', 'install', '-r', 'requirements.txt'], stderr=subprocess.DEVNULL)
        else:
            subprocess.check_output(['python', '-m' 'pip', 'install', '-r', 'requirements.txt'])
    except Exception as err:
        print()
        print_and_log('Error occured while installing python dependencies. Try running "pip install -r requirements.txt". Error: {}'.format(err))
        print()


def upgrade_postprocess(len_template, tenants, services, date, change_in_envs, read_template_docker, replace_mapping):
    """
    Upgrade process after pulling the latest changes from git
    """
    # Read the newly fetched template
    read_updated_template = \
        read_yaml(os.path.join(TEMPLATE_DIR, 'docker-compose.yml'))['services']['<tenant_name>.goskope.com'][
            'environment']
    len_updated_template = len(read_updated_template)

    # Updated docker image
    updated_image = \
        read_yaml(os.path.join(TEMPLATE_DIR, 'docker-compose.yml'))['services']['<tenant_name>.goskope.com'][
            'image']

    if len_template >= len_updated_template:  # No changes in docker-compose
        change_in_envs = check_for_env_updates(tenants, date)

        if len(change_in_envs) == 0:  # No changes in env file(s)
            edited_docker_compose = {}

            for service_key, service_val in services.items():
                service_val = upgrade_image(service_val, updated_image)
                edited_docker_compose = copy.deepcopy(read_yaml(TEMPLATE_DOCKER_COMPOSE_PATH))

            edited_docker_compose['services'] = services
            write_yml(os.path.join(CONFIG_DIR, 'docker-compose.yml'), edited_docker_compose)
            print()
            print_and_log('No new configuration parameters added.')

        else:
            edited_service = upgrade_docker_compose({}, services, tenants, date, updated_image)
            write_yml(os.path.join(CONFIG_DIR, 'docker-compose.yml'), edited_service)
    else:  # There are changes in docker-compose
        config_obj = compare_template(read_template_docker, read_updated_template)
        services = read_yaml(os.path.join(BKP_PATH, 'cls_backup_{}'.format(date.strftime("%Y-%m-%dT%Hh%Mm%Ss")),
                                          'docker-compose.yml'))['services']
        edited_service = upgrade_docker_compose(config_obj, services, tenants, date, updated_image)
        write_yml(os.path.join(CONFIG_DIR, 'docker-compose.yml'), edited_service)

    # If any parameters are changed, ask user whether he/she wants to stop and upgrade the running CLS containers
    if not len_template >= len_updated_template or not len(change_in_envs) == 0:
        print_and_log('Successfully updated all the configurations with the latest changes.')

    # Replace the mapping json files of all the installed plugins
    if replace_mapping:
        helpers.replace_mapping_file(services)

    # Check if docker container(s) is/are running

    if is_container_running():
        print(
            'In order to reflect the latest changes (if any), running docker container(s) must be stopped and started '
            'again. '
        )
        agreement = get_input('Do you want to stop the running docker container(s) now? (y/n): ')

        while agreement not in VALID_BOOLEAN_INPUTS:
            agreement = get_input('Invalid choice. Try again (y/n): ')

        agreement = agreement in POSITIVE_BOOLEAN_INPUTS

        if agreement:
            stop_containers()
        else:
            print_and_log(
                'In order to reflect the latest changes (if any) later on, stop and restart the running container(s) '
                'with following commands. '
            )

    print_commands('> sudo docker-compose pull && sudo docker-compose up -d')


def get_mapping_file(env_path, configured_envs):
    """
    Fetches the value of the mapping file from given env file configuration
    """
    env_path = os.path.join(CONFIG_DIR, env_path)
    for env_obj in configured_envs:
        if env_obj['path'] == env_path:
            if 'SYSLOG_MAP' in env_obj['env_obj']:
                return env_obj['env_obj']['SYSLOG_MAP']
            elif 'CSCC_MAP' in env_obj['env_obj']:
                return env_obj['env_obj']['CSCC_MAP']
            elif 'AZURE_SENTINEL_MAP' in env_obj['env_obj']:
                return env_obj['env_obj']['AZURE_SENTINEL_MAP']
            elif 'MCAS_MAP' in env_obj['env_obj']:
                return env_obj['env_obj']['MCAS_MAP']
    return None
