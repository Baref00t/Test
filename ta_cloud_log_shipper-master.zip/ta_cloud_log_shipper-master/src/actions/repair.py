"""Implements the repair action"""

import os
import copy
import shutil
import logging
import datetime
import subprocess

from ..helpers import (
    clear,
    encrypt,
    read_env,
    copytree,
    read_yaml,
    get_input,
    write_yml,
    write_env,
    copy_file,
    iterate_dirs,
    is_installed,
    print_and_log,
    print_commands,
    sanitize_input,
    print_separator,
    print_for_review

)
from ..constants import (
    WIDTH,
    BKP_PATH,
    PLUGIN_MCAS,
    TOOLTIPS,
    LOG_LEVEL,
    CONFIG_DIR,
    SETUP_MODES,
    AVAILABLE_VALS,
    VALID_BOOLEAN_INPUTS,
    ENV_SECURE_ATTRIBUTES,
    POSITIVE_BOOLEAN_INPUTS,
    FIELD_EXCLUDED_FROM_LOGS,
    DOCKER_COMPOSE_SECURE_ATTRIBUTES

)
from .action_helpers import (
    get_volumes,
    ENV_TEMPLATE,
    add_new_service,
    get_syslog_protocol,
    get_mapping_file,
    validate_docker_config,
    DOCKER_COMPOSE_TEMPLATE,
    check_and_stop_containers,
    validate_mapping_file_path,
    create_config_dir_structure,
    check_and_stop_multiple_containers
)
from ..logger_manager import LoggerManager

logger = LoggerManager('setup', LOG_LEVEL).get_logger()


def edit_params(config_obj, excluded=[], enable_logging=True):
    """
    Asks user to edit parameters from given configuration object

    :param enable_logging: Whether the logging is enabled or not
    :param config_obj: Configuration object to be edited
    :param excluded: List of excluded parameters from being edited
    :returns: Edited configuration object
    """
    print(
        'Enter new values to override existing values. Press ENTER to keep the existing values. Enter "None" to set '
        'empty value.'
    )
    print()

    for key, val in config_obj.items():
        if key in excluded:
            continue

        if key in ['ALERT_TYPE', 'ALERT_QUERY'] and config_obj['PLUGIN_TYPE'].lower() == PLUGIN_MCAS:
            config_obj[key] = None
            continue

        # Don't ask for number of threads if deduplication is enabled
        if key == 'N_THREADS' and str(config_obj['ENABLE_DEDUPLICATION']).lower() in POSITIVE_BOOLEAN_INPUTS:
            continue

        # Don't ask for cert file if selected protocol is not TLS
        if key == 'SYSLOG_CERT_FILE' and 'SYSLOG_PROTOCOL' in config_obj and str(
                config_obj['SYSLOG_PROTOCOL']).lower() != 'tls':
            continue

        # Don't ask for cert file and key file names here.
        if key in ['SYSLOG_CERT_FILE', 'KEY_FILE']:
            continue

        if key in TOOLTIPS:
            print('Note: ' + TOOLTIPS[key])

        if key in AVAILABLE_VALS:
            inp = get_input('Enter value for {} (existing: {} | available: {}): '.format(
                key,
                val if val else '<empty>',
                ','.join(list(map(str, AVAILABLE_VALS[key])))
            ), lower=False)

        elif key in ['SYSLOG_MAP', 'CSCC_MAP', 'AZURE_SENTINEL_MAP', 'MCAS_MAP']:
            inp = get_input('Enter value for {} (existing: {}): '.format(key, val if val else '<empty>'), lower=False)
            if inp:
                inp = validate_mapping_file_path(inp)
            else:
                inp = validate_mapping_file_path(val)

        else:
            inp = get_input('Enter value for {} (existing: {}): '.format(key, val if val else '<empty>'), lower=False)

        if inp.lower() == 'none':
            config_obj[key] = None
            config_obj[key] = validate_docker_config(key, config_obj[key])
            print()

            if config_obj[key] and enable_logging:
                logger.info('Value entered for configuration key "{}": {}'.format(key, config_obj[key]))
            elif enable_logging:
                logger.info('Empty value selected for configuration key "{}"'.format(key))

            continue

        is_default = False
        if inp:
            config_obj[key] = sanitize_input(inp)
            # Only encrypt the value if user has provided new one. In case of default value, it
            # won't be encrypted.
            if (
                key in ENV_SECURE_ATTRIBUTES or
                key in DOCKER_COMPOSE_SECURE_ATTRIBUTES
            ):
                config_obj[key] = encrypt(key, config_obj[key])

        elif val:
            if key not in FIELD_EXCLUDED_FROM_LOGS and enable_logging:
                logger.info('Existing value "{}" selected for configuration key "{}"'.format(val, key))
                is_default = True
            config_obj[key] = val
        else:
            config_obj[key] = None
        print()
        config_obj[key] = validate_docker_config(key, config_obj[key])

        inp_value = config_obj[key]
        if key not in FIELD_EXCLUDED_FROM_LOGS and not is_default and enable_logging:
            if inp_value:
                logger.info('Value entered for configuration key "{}": {}'.format(key, inp_value))
            else:
                logger.info('Empty value selected for configuration key "{}"'.format(key))

    return config_obj


def save_backup():
    """
    Saves the backup of given list of directories to a specific path.
    """

    # Save the backup
    now = datetime.datetime.now()

    try:
        bkp_dirs = get_volumes(os.path.join(CONFIG_DIR, 'docker-compose.yml'))
        bkp_dirs.append(os.path.join(CONFIG_DIR, 'env'))
        bkp_dirs = set(bkp_dirs)

        backup_dir = os.path.join(BKP_PATH, 'cls_backup_{}'.format(now.strftime("%Y-%m-%dT%Hh%Mm%Ss")))
        os.makedirs(backup_dir)

        for dir_path in bkp_dirs:
            copytree(dir_path, backup_dir)
        copy_file(os.path.join(CONFIG_DIR, 'docker-compose.yml'), backup_dir)
    except Exception as err:
        print_and_log('An error occurred while creating backup of configurations. Error: {}'.format(err))
    return now


def get_valid_path(file_type, tenant_name):
    """
    Asks user for the path of file to be copied to configuration dirs

    :param: file_type: the type of file being copied
    :param: the tenant name for which the operation is being performed
    :returns: The validated file path entered by user
    """
    # Ask for Google Service account key file path
    file = get_input('Enter the path of {} file for '
                     'tenant "{}": '.format(file_type, tenant_name), lower=False)
    logger.info('Entered path for {} file: {}'.format(file_type, file))
    while not file or not os.path.exists(file):
        logger.info('Invalid path provided for {} file: {}'.format(file_type, file))
        file = get_input('Invalid path provided. Try again: ', lower=False)

    return file


def _edit_existing_integration():
    """
    To edit existing configuration parameters
    """
    try:
        commands = []
        services_edited = []
        while True:
            clear()
            # First read the configured docker compose
            services = read_yaml(os.path.join(CONFIG_DIR, 'docker-compose.yml'))['services']

            service_key_choice_dict = {}
            num_services = len(services.keys())
            print('Found {} integration(s) installed:'.format(num_services))

            for index, (service_key, service) in enumerate(services.items()):
                print('> Press {} to edit configurations of integration "{}"'.format(index + 1, service_key))
                service_key_choice_dict[str(index + 1)] = service_key
            print('> Press Q to Quit')
            print()

            choice_range = [str(choice + 1) for choice in range(num_services)]
            choice_range.append('q')

            inp = get_input('Enter your choice: ')
            while inp not in choice_range:
                inp = get_input('Invalid choice. Try again ({}): '.format('/'.join(choice_range)))

            if inp == 'q':
                logger.info('Quitting the installer on user preference.')
                return True
            service_choice = inp

            edited_envs = []

            # For each service, ask for env file params and environment parameters
            # for service_key,  service in services.items():
            target_service = services[service_key_choice_dict[inp]]
            target_service_key = service_key_choice_dict[inp]

            print_separator()
            print('Edit parameters for integration "{}"'.format(service_key_choice_dict[inp]))
            print_separator()

            env_file = os.path.join(CONFIG_DIR, target_service['env_file'][0])
            environment = target_service['environment']
            plugin_type = str(target_service['environment']['PLUGIN_TYPE']).lower()

            edit_params(environment, ['TENANT_NAME', 'PLUGIN_TYPE', 'VERIFY_SSL'])

            print_separator()
            print('Edit env file parameters for integration "{}"'.format(service_key_choice_dict[inp]))
            print_separator()

            # if env file is not present while editing, we need to create new one and save it
            edited_env = copy.deepcopy(ENV_TEMPLATE[plugin_type])

            if os.path.isfile(env_file):
                edited_env = read_env(env_file)

            edited_envs.append({
                'path': env_file,
                'env_obj': edit_params(edited_env, enable_logging=False)
            })

            edited_docker_compose = copy.deepcopy(DOCKER_COMPOSE_TEMPLATE)
            edited_docker_compose['services'] = services
            print_for_review(target_service, edited_envs)

            inp = get_input('Do you want to proceed with the above configurations? (y/n): ')
            while inp not in VALID_BOOLEAN_INPUTS:
                inp = get_input('Invalid choice. Try again (y/n): ')

            inp = inp in POSITIVE_BOOLEAN_INPUTS
            if inp:
                print()
                # Change the path in case of mapping file
                if environment['PLUGIN_TYPE'].lower() == 'syslog':
                    copy_file(edited_envs[0]['env_obj']['SYSLOG_MAP'],
                              edited_docker_compose['services'][target_service_key]['volumes'][0].split(':')[0])
                elif environment['PLUGIN_TYPE'].lower() == 'cscc':
                    copy_file(edited_envs[0]['env_obj']['CSCC_MAP'],
                              edited_docker_compose['services'][target_service_key]['volumes'][0].split(':')[0])
                elif environment['PLUGIN_TYPE'].lower() == 'azure_sentinel':
                    copy_file(edited_envs[0]['env_obj']['AZURE_SENTINEL_MAP'],
                              edited_docker_compose['services'][target_service_key]['volumes'][0].split(':')[0])
                elif environment['PLUGIN_TYPE'].lower() == 'mcas':
                    copy_file(edited_envs[0]['env_obj']['MCAS_MAP'],
                              edited_docker_compose['services'][target_service_key]['volumes'][0].split(':')[0])
                # Ask for key file/cert file
                target_file_name = ''
                print_separator()
                if environment['PLUGIN_TYPE'] == 'cscc':
                    print('CSCC Plugin requires Google Service Account Key configuration'.center(WIDTH))
                    print_separator()
                    agreement = get_input(
                        'Existing value of Google Service account key is: "{}". Do you want to change the Google '
                        'Service account key file? (y/n): '.format(
                            edited_envs[0]['env_obj']['KEY_FILE'] if edited_envs[0]['env_obj'][
                                'KEY_FILE'] else '<empty>')
                    )
                    while agreement not in VALID_BOOLEAN_INPUTS:
                        agreement = get_input('Invalid choice. Try again (y/n): ')

                    agreement = agreement in POSITIVE_BOOLEAN_INPUTS
                    if agreement:
                        path = get_valid_path('Google Service account key', environment['TENANT_NAME'])
                        target_file_name = 'KEY_FILE'

                elif environment['PLUGIN_TYPE'] == 'syslog' and str(edited_envs[0]['env_obj'][
                                                                        'SYSLOG_PROTOCOL']).lower() == 'tls':
                    print('Syslog Plugin with TLS protocol requires a certificate file'.center(WIDTH))
                    print_separator()
                    agreement = get_input(
                        'Existing value of syslog cert file is: "{}". Do you want to change the cert file? (y/n):'
                        ' '.format(
                            edited_envs[0]['env_obj']['SYSLOG_CERT_FILE']
                            if edited_envs[0]['env_obj']['SYSLOG_CERT_FILE'] else '<empty>'
                        )
                    )
                    while agreement not in VALID_BOOLEAN_INPUTS:
                        agreement = get_input('Invalid choice. Try again (y/n): ')

                    agreement = agreement in POSITIVE_BOOLEAN_INPUTS
                    if agreement:
                        path = get_valid_path('certificate', environment['TENANT_NAME'])
                        target_file_name = 'SYSLOG_CERT_FILE'

                if target_file_name:
                    # Copy the given file and also update in the env file
                    copy_file(path,
                              edited_docker_compose['services'][target_service_key]['volumes'][0].split(':')[0])
                    edited_envs[0]['env_obj'][target_file_name] = os.path.basename(path)

                if not os.path.isdir(CONFIG_DIR):
                    os.mkdir(CONFIG_DIR)

                if not os.path.isdir(os.path.join(CONFIG_DIR, 'env')):
                    os.mkdir(os.path.join(CONFIG_DIR, 'env'))

                # Save docker-compose
                write_yml(os.path.join(CONFIG_DIR, 'docker-compose.yml'), edited_docker_compose)
                print_and_log('Docker-compose file with given configurations updated successfully.')

                # Save env files
                write_env(edited_envs)
                print_and_log('Env file(s) with given configurations updated successfully.')

                commands.append('> sudo docker-compose up -d {}'.format(target_service_key))
                services_edited.append(service_key_choice_dict[service_choice])

                inp = get_input('Do you want to edit configurations of the same/another integration? (y/n): ')
                while inp not in VALID_BOOLEAN_INPUTS:
                    inp = get_input('Invalid choice. Try again (y/n): ')

                inp = inp in POSITIVE_BOOLEAN_INPUTS
                if not inp:
                    if not check_and_stop_multiple_containers(services_edited):
                        return False
                    print_commands('\n'.join(set(commands)))
                    break
            else:
                print_and_log('Aborting the repair. Re-run the script in order to configure different parameters.')
                return False
        return True
    except Exception as err:
        print_and_log('An error occurred while repairing Netskope CLS. Error: {}'.format(err), logging.ERROR)
        return False


def _add_new_integration():
    """
    To add new service via repair
    """
    try:
        result = add_new_service(SETUP_MODES['REPAIR'])
        if not result['success']:
            return False

        docker_compose_dict, configured_envs = result['conf']['docker_compose_dict'], result['conf'][
            'configured_envs']
        print_for_review(docker_compose_dict, configured_envs)

        inp = get_input('Do you want to proceed repair with the above configurations? (y/n): ')
        while inp not in VALID_BOOLEAN_INPUTS:
            inp = get_input('Invalid choice. Try again (y/n): ')

        inp = inp in POSITIVE_BOOLEAN_INPUTS

        if inp:
            print()

            # First create all directory structures
            for _, service_obj in docker_compose_dict['services'].items():
                result = create_config_dir_structure(service_obj['environment']['PLUGIN_TYPE'],
                                                     service_obj['environment']['TENANT_NAME'],
                                                     service_obj['volumes'][:2],
                                                     get_syslog_protocol(service_obj['env_file'][0],
                                                                         configured_envs),
                                                     get_mapping_file(service_obj['env_file'][0], configured_envs))
                if not result['success']:
                    return False

                copied_file = result['copied_file']
                for env_obj in configured_envs:
                    if env_obj['path'] == os.path.join(CONFIG_DIR, service_obj['env_file'][0]) and \
                            result['key_name'] in env_obj['env_obj']:
                        env_obj['env_obj'][result['key_name']] = os.path.basename(copied_file)

            print()
            print_and_log('The directory structure for configured services created successfully.')

            if not os.path.isdir(CONFIG_DIR):
                os.mkdir(CONFIG_DIR)

            if not os.path.isdir(os.path.join(CONFIG_DIR, 'env')):
                os.mkdir(os.path.join(CONFIG_DIR, 'env'))

            existing_docker_compose = read_yaml(os.path.join(CONFIG_DIR, 'docker-compose.yml'))

            existing_docker_compose['services'].update(docker_compose_dict['services'])
            write_yml(os.path.join(CONFIG_DIR, 'docker-compose.yml'), existing_docker_compose)
            print_and_log('Docker-compose file with given configurations saved successfully.')

            write_env(configured_envs)
            print_and_log('Env file(s) with given configurations saved successfully.')
            print_commands('> sudo docker-compose up -d --no-recreate')
        else:
            print_and_log(
                'Aborting the repair process. Re-run the script in order to configure different parameters.')
            return False
    except Exception as err:
        print_and_log('An error occurred while repairing Netskope CLS. Error: {}'.format(err), logging.ERROR)
        return False
    return True


def _delete_integration():
    """
    To delete an existing service via repair
    """
    try:
        while True:
            clear()

            # First read the configured docker compose
            services = read_yaml(os.path.join(CONFIG_DIR, 'docker-compose.yml'))['services']

            service_key_choice_dict = {}
            num_services = len(services.keys())
            print('Found {} integration(s) installed:'.format(num_services))

            for index, (service_key, service) in enumerate(services.items()):
                print('> Press {} to remove integration "{}"'.format(index + 1, service_key))
                service_key_choice_dict[str(index + 1)] = service_key
            print('> Press Q to Quit')
            print()

            choice_range = [str(choice + 1) for choice in range(num_services)]
            choice_range.append('q')

            inp = get_input('Enter your choice: ')
            while inp not in choice_range:
                inp = get_input('Invalid choice. Try again ({}): '.format('/'.join(choice_range)))

            if inp == 'q':
                logger.info('Quitting the installer on user preference.')
                return True

            service_choice = inp

            # Print files being removed in case of integration removal
            print_separator()
            print('Following files will be deleted in the process of integration removal:')
            print_separator()

            env_path = os.path.join(CONFIG_DIR, services[service_key_choice_dict[service_choice]]['env_file'][0])
            config_dir_path = services[service_key_choice_dict[service_choice]]['volumes'][0].split(':')[0]

            print('Docker container of selected integration.')

            print(env_path)
            print('\n'.join(iterate_dirs(config_dir_path)))
            print()

            logger.info('\n'.join(['Following files will be deleted in the process of integration removal:',
                                   'Docker container of selected integration.', env_path, config_dir_path]))

            inp = get_input('Are you sure you want to proceed with removal of selected integration? (y/n): ')
            while inp not in VALID_BOOLEAN_INPUTS:
                inp = get_input('Invalid choice. Try again (y/n): ')

            inp = inp in POSITIVE_BOOLEAN_INPUTS

            if not inp:
                print_and_log('Exiting from the Netskope CLS setup.')
                return True

            print()
            inp = get_input(
                'If you want to remove selected integration, type \'DELETE\', otherwise type \'exit\': ')
            while not (inp == 'delete' or inp == 'exit'):
                inp = get_input('Invalid input. Try again (DELETE/exit): ')

            logger.info('Choice of uninstall "{}"'.format(inp))
            inp = inp == 'delete'

            if not inp:
                print_and_log('Exiting from the Netskope CLS setup.')
                return True

            # Ask user to stop the container
            if not check_and_stop_containers(service_key_choice_dict[service_choice]):
                return False

            # Remove the container
            try:
                subprocess.Popen(['docker-compose', 'rm', '-f', service_key_choice_dict[service_choice]],
                                 cwd=CONFIG_DIR).wait()
            except Exception as err:
                print_and_log('An error occurred while removing docker container. Error: {}'.format(err), logging.ERROR)
                return False

            # Remove service component from docker-compose
            services.pop(service_key_choice_dict[service_choice])

            edited_docker_compose = copy.deepcopy(DOCKER_COMPOSE_TEMPLATE)
            edited_docker_compose['services'] = services
            write_yml(os.path.join(CONFIG_DIR, 'docker-compose.yml'), edited_docker_compose)

            # If services dict is empty, delete docker compose as all the services are removed
            if not services:
                logger.info('No integrations are left in docker-compose. Removing entire file.')
                os.remove(os.path.join(CONFIG_DIR, 'docker-compose.yml'))
            else:
                print_and_log('Docker-compose file with given configurations updated successfully.')

            try:
                # Remove corresponding env file
                os.remove(env_path)
                print_and_log('Successfully removed env file: "{}"'.format(env_path))

                # If no env files are left in env dir, remove dir
                if not os.listdir(os.path.join(CONFIG_DIR, 'env')):
                    os.rmdir(os.path.join(CONFIG_DIR, 'env'))

                # If config dir is empty, remove it
                if not os.listdir(CONFIG_DIR):
                    os.rmdir(CONFIG_DIR)

            except FileNotFoundError as err:
                print_and_log('Could not find env file at path: "{}". Error: {}'.format(env_path, err),
                              logging.ERROR)
                # No need to return False as our task is already done
            except Exception as err:
                print_and_log('An error occurred while removing existing integration. Error: {}'.format(err),
                              logging.ERROR)
                return False

            try:
                shutil.rmtree(config_dir_path)
                print_and_log('Configurations of selected integration removed successfully.')
            except Exception as err:
                print_and_log(
                    'An error occurred while removing existing integration\'s configurations. Error: {}'.format(
                        err), logging.ERROR)
                return False

            if not is_installed(enable_printing=False):
                break

            print()
            inp = get_input('Do you want to remove another integration? (y/n): ')
            while inp not in VALID_BOOLEAN_INPUTS:
                inp = get_input('Invalid choice. Try again (y/n): ')

            inp = inp in POSITIVE_BOOLEAN_INPUTS
            if not inp:
                print('Exiting the setup.')
                break

    except Exception as err:
        print_and_log('An error occurred while repairing Netskope CLS. Error: {}'.format(err), logging.ERROR)
        return False
    return True


def repair():
    """
    Performs repair for Netskope CLS.

    :returns: True in case of success, False otherwise
    """

    # First check whether Netskope CLS is installed or not
    if not is_installed():
        print_and_log(
            'It seems that Netskope CLS is not installed yet or corrupted. First, you need to install Netskope CLS.')
        return False

    clear()
    print_separator()
    print('Netskope CLS Repair'.center(WIDTH))
    print_separator()

    print('> Press 1 to edit existing integration(s)')
    print('> Press 2 to add new integration(s)')
    print('> Press 3 to remove existing integration(s)')
    print('> Press Q to Quit')
    print()

    choice = get_input('Enter your choice: ')
    while choice not in ['1', '2', '3', 'q']:
        choice = get_input('Invalid choice. Try again (1/2/3/Q): ')

    if choice == 'q':
        logger.info('Quitting the installer on user preference.')
        return True

    # Save the backup before proceeding
    save_backup()

    # In case of edit existing parameters
    if choice == '1':
        return _edit_existing_integration()

    # In case of adding a new integration
    elif choice == '2':
        clear()
        print_separator()
        print('Enter configuration parameters for new integration')
        print_separator()

        return _add_new_integration()

    # In case of deleting an existing service (Integration)
    else:
        return _delete_integration()
