"""Implements the install action for CLS installation"""

import os
import logging

from ..logger_manager import LoggerManager
from ..helpers import (
    get_input,
    write_yml,
    write_env,
    print_and_log,
    print_for_review,
    copy_proxy_after_install
)
from .action_helpers import (
    add_new_service
)

from ..constants import (
    LOG_LEVEL,
    CONFIG_DIR,
    SETUP_MODES,
    VALID_BOOLEAN_INPUTS,
    POSITIVE_BOOLEAN_INPUTS
)
from .action_helpers import create_config_dir_structure, get_syslog_protocol, get_mapping_file

logger = LoggerManager('setup', LOG_LEVEL).get_logger()


def install():
    """
    Function for Netskope CLS installation, which asks user inputs from user for docker-compose and
    corresponding env file

    :returns: True in case of successful configuration, False otherwise
    """
    try:
        result = add_new_service(SETUP_MODES['INSTALL'])
        if not result['success']:
            return False

        docker_compose_dict, configured_envs = result['conf']['docker_compose_dict'], result['conf']['configured_envs']
        print_for_review(docker_compose_dict, configured_envs)

        # Ask for review the configurations before saving
        inp = get_input('Do you want to proceed installation with the above configurations? (y/n): ')
        while inp not in VALID_BOOLEAN_INPUTS:
            inp = get_input('Invalid choice. Try again (y/n): ')

        inp = inp in POSITIVE_BOOLEAN_INPUTS

        if inp:
            print()
            # First create all directory structures
            for _, service_obj in docker_compose_dict['services'].items():
                result = create_config_dir_structure(
                    service_obj['environment']['PLUGIN_TYPE'],
                    service_obj['environment']['TENANT_NAME'],
                    service_obj['volumes'][:2],
                    get_syslog_protocol(service_obj['env_file'][0], configured_envs),
                    get_mapping_file(service_obj['env_file'][0], configured_envs)
                )

                if not result['success']:
                    return False

                copied_file = result['copied_file']

                for env_obj in configured_envs:
                    if env_obj['path'] == os.path.join(CONFIG_DIR, service_obj['env_file'][0]) and \
                            result['key_name'] in env_obj['env_obj']:
                        env_obj['env_obj'][result['key_name']] = os.path.basename(copied_file)

            print()
            print_and_log('The directory structure for configured integration(s) created successfully.')

            if not os.path.isdir(CONFIG_DIR):
                os.mkdir(CONFIG_DIR)

            if not os.path.isdir(os.path.join(CONFIG_DIR, 'env')):
                os.mkdir(os.path.join(CONFIG_DIR, 'env'))

            # Save docker-compose
            write_yml(os.path.join(CONFIG_DIR, 'docker-compose.yml'), docker_compose_dict)
            print_and_log('Docker-compose file with given configurations saved successfully.')

            # Save env files
            write_env(configured_envs)
            print_and_log('Env file(s) with given configurations saved successfully.')

            # Save proxy env file also if proxy is not configured already
            copy_proxy_after_install()
        else:
            print_and_log('Aborting the installation. Re-run the script in order to configure different parameters.')
            return False

    except Exception as err:
        print_and_log('An error occurred while installing Netskope CLS. Error: {}'.format(err), logging.ERROR)
        return False
    return True
