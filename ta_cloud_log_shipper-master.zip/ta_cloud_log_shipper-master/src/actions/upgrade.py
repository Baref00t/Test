import os
from importlib import reload
from .. import constants
from .. import helpers
from .. import logger_manager
from ..actions import install
from ..actions import repair
from ..actions import uninstall
from . import action_helpers
from ..constants import VALID_BOOLEAN_INPUTS, POSITIVE_BOOLEAN_INPUTS
from ..helpers import get_input

from ..logger_manager import LoggerManager

logger = LoggerManager('setup', constants.LOG_LEVEL).get_logger()


def refresh_imports():
    """
    Refreshes all the imports to load the newly available code after upgrade

    :returns: all the newly available import objects
    """
    global constants, helpers, install, repair, uninstall, action_helpers, logger_manager
    constants = reload(constants)
    helpers = reload(helpers)
    install = reload(install)
    repair = reload(repair)
    uninstall = reload(uninstall)
    action_helpers = reload(action_helpers)
    logger_manager = reload(logger_manager)
    return constants, helpers, install, repair, uninstall, action_helpers, logger_manager


def upgrade_without_configurations():
    """
    Checks for change(s) in docker-compose when CLS is not installed (when CLS configuration
    files are not present in the configuration directory)
    """
    global constants, helpers, install, repair, uninstall, action_helpers, logger_manager
    helpers.clear()
    try:
        read_template_docker = helpers.read_yaml(
            os.path.join(constants.TEMPLATE_DIR, 'docker-compose.yml')
        )['services']['<tenant_name>.goskope.com']['environment']
        len_template = len(read_template_docker)

        helpers.print_separator()
        helpers.print_and_log('pulling the latest changes from GitHub...')
        helpers.print_separator()

        if action_helpers.git_pull():
            action_helpers.install_dependencies()
            helpers.print_separator()
            # Reload all files
            constants, helpers, install, repair, uninstall, action_helpers, logger_manager = refresh_imports()

            action_helpers.read_latest_docker_template(len_template)

        else:
            exit(0)
    except Exception as err:
        helpers.print_and_log_error(err)


def upgrade_with_configurations(date):
    """
    Makes changes (updates) the existing docker-compose and env files based on the updated template files (if any)

    :param date: The date of backup
    """
    global constants, helpers, install, repair, uninstall, action_helpers, logger_manager
    try:
        print()
        replace_mapping = get_input('Enter y/yes to proceed upgrade along with replacing the mapping file(s) of '
                                    'currently configured plugin(s) with the latest mapping file(s), '
                                    'enter n/no to proceed upgrade without replacing the mapping file(s): ')

        while replace_mapping not in VALID_BOOLEAN_INPUTS:
            replace_mapping = get_input('Invalid choice. Try again (y/n): ')

        replace_mapping = replace_mapping in POSITIVE_BOOLEAN_INPUTS

        helpers.clear()
        change_in_envs = []

        # Read the docker-compose template before upgrade
        read_template_docker = \
            helpers.read_yaml(os.path.join(constants.TEMPLATE_DIR, 'docker-compose.yml'))['services'][
                '<tenant_name>.goskope.com'][
                'environment']
        len_template = len(read_template_docker)

        # Reading the configured docker-compose from backup
        services = helpers.read_yaml(
            os.path.join(constants.BKP_PATH, 'cls_backup_{}'.format(date.strftime("%Y-%m-%dT%Hh%Mm%Ss")),
                         'docker-compose.yml'))[
            'services']
        tenants = []

        for service_key, service_val in services.items():
            tenants.append(service_val['environment']['TENANT_NAME'])

        helpers.print_separator()
        helpers.print_and_log('Pulling the latest changes from GitHub...')
        helpers.print_separator()

        if action_helpers.git_pull():
            action_helpers.install_dependencies()
            print()
            helpers.print_separator()
            helpers.print_and_log('Successfully pulled all the latest changes.')
            helpers.print_separator()
        else:
            exit(0)

        # Reload all the imports
        constants, helpers, install, repair, uninstall, action_helpers, logger_manager = refresh_imports()
        action_helpers.upgrade_postprocess(len_template, tenants, services, date, change_in_envs, read_template_docker,
                                           replace_mapping)

    except Exception as err:
        helpers.print_and_log_error(err)
        exit(0)
