import copy
import logging
import os

from ..helpers import (
    clear,
    encrypt,
    write_env,
    get_input,
    print_and_log,
    sanitize_input,
    print_separator,
    print_envs,
    get_proxy_env,
    is_installed,
    print_commands
)
from ..constants import (
    WIDTH,
    TOOLTIPS,
    LOG_LEVEL,
    CONFIG_DIR,
    VALID_BOOLEAN_INPUTS,
    POSITIVE_BOOLEAN_INPUTS,
    NEGATIVE_BOOLEAN_INPUTS,
    FIELD_EXCLUDED_FROM_LOGS,
    ENV_SECURE_ATTRIBUTES,
    DOCKER_COMPOSE_SECURE_ATTRIBUTES,
    AVAILABLE_VALS,
    SETUP_LOGS_PATH
)
from .action_helpers import (
    validate_docker_config,
    is_container_running,
    stop_containers
)
from ..logger_manager import LoggerManager

logger = LoggerManager('setup', LOG_LEVEL).get_logger()
PROXY_ENV = get_proxy_env()


def print_proxy_intro():
    clear()
    print_separator()
    print('Netskope CLS Proxy Configuration'.center(WIDTH))
    print_separator()
    print('Enter new values to override existing values. Press ENTER to keep the existing values.')
    print()
    print('Enter the values for Proxy Configuration')
    print()


def print_proxy_conclusion():
    """
    Prints details for user after user has configured the proxy successfully
    """
    print_separator()
    print_and_log('Proxy configured successfully.')
    print_separator()

    if not is_installed(enable_printing=False):
        exit(0)
    elif is_container_running():
        print(
            'In order to reflect the latest changes (if any), running docker container(s) must be stopped and started '
            'again.'
        )
        agreement = get_input('Do you want to stop the running docker container(s) now? (y/n): ')

        while agreement not in VALID_BOOLEAN_INPUTS:
            agreement = get_input('Invalid choice. Try again (y/n): ')

        agreement = agreement in POSITIVE_BOOLEAN_INPUTS

        if agreement:
            stop_containers()
        else:
            print(
                'In order to reflect the latest changes (if any) later on, stop and restart the running container(s) '
                'with following commands.'
            )
    print_commands()
    exit(0)


def pre_write_checks():
    """
    Check if the config and env directory exists.
    If it doesn't exists, then create it.
    """
    if not os.path.isdir(CONFIG_DIR):
        os.mkdir(CONFIG_DIR)

    if not os.path.isdir(os.path.join(CONFIG_DIR, 'env')):
        os.mkdir(os.path.join(CONFIG_DIR, 'env'))


def configure_proxy():
    """
    Main function for proxy configuration
    """
    print_proxy_intro()

    try:
        proxy_env = copy.deepcopy(PROXY_ENV)
        for key, val in proxy_env.items():

            # Don't ask for other proxy parameters, if proxy is disabled
            if (
                    key in ['PROXY_SERVER', 'PROXY_SCHEME', 'PROXY_PORT', 'AUTHENTICATED_PROXY', 'USERNAME',
                            'PASSWORD'] and
                    str(proxy_env['ENABLE_PROXY']).lower() in NEGATIVE_BOOLEAN_INPUTS
            ):
                continue

            # Don't ask for credentials, if proxy authentication is disabled
            if (
                    key in ['USERNAME', 'PASSWORD'] and
                    str(proxy_env['AUTHENTICATED_PROXY']).lower() in NEGATIVE_BOOLEAN_INPUTS
            ):
                continue

            if key in TOOLTIPS:
                print('Note: ' + TOOLTIPS[key])

            if key in AVAILABLE_VALS:
                inp = get_input(
                    'Enter value for {} (existing: {} | available: {}): '.format(
                        key,
                        val if val else '<empty>',
                        ','.join(list(map(str, AVAILABLE_VALS[key])))
                    )
                )
            else:
                inp = get_input('Enter value for {} (existing: {}): '.format(
                    key,
                    val if val else '<empty>'
                ), lower=False)

            if inp.lower() == 'none':
                proxy_env[key] = None
                proxy_env[key] = validate_docker_config(key, proxy_env[key])
                if proxy_env[key]:
                    logger.info('Value entered for proxy key "{}": {}'.format(
                        key,
                        proxy_env[key])
                    )
                else:
                    logger.info('Empty value selected for proxy key "{}"'.format(key))
                print()
                continue
            if inp:
                proxy_env[key] = sanitize_input(inp)

                # Only encrypt the value if user has provided new one. In case of default value, it
                # won't be encrypted.
                if (
                    key in ENV_SECURE_ATTRIBUTES or
                    key in DOCKER_COMPOSE_SECURE_ATTRIBUTES
                ):
                    proxy_env[key] = encrypt(key, proxy_env[key])
            elif val:
                proxy_env[key] = val
            else:
                proxy_env[key] = None

            proxy_env[key] = validate_docker_config(key, proxy_env[key])
            if key not in FIELD_EXCLUDED_FROM_LOGS:
                if proxy_env[key]:
                    logger.info('Value for proxy key "{}": {}'.format(key, proxy_env[key]))
                else:
                    logger.info('Empty value selected for proxy key "{}"'.format(key))
            print()

        result = []
        proxy_configured_env = {
            'path': os.path.join(CONFIG_DIR, 'env', '{}.env'.format('common_config')),
            'env_obj': proxy_env
        }
        result.append(proxy_configured_env)
        clear()
        print_separator()
        print('Review configured values'.center(WIDTH))
        print_separator()
        print_envs(result)

        # Ask for review the configurations before saving
        inp = get_input('Do you want to continue with the above configurations for proxy? (y/n): ')
        while inp not in VALID_BOOLEAN_INPUTS:
            inp = get_input('Invalid choice. Try again (y/n): ')
        inp = inp in POSITIVE_BOOLEAN_INPUTS
        if not inp:
            print_and_log('Aborting the proxy configuration.'
                          ' Re-run the script in order to configure different parameters.')
            exit(0)
        pre_write_checks()
        write_env(result)

        print_proxy_conclusion()
    except Exception as err:
        print_and_log(
            'An error occurred while configuring env file for proxy. Error: {}'.format(err), logging.ERROR
        )
        print('Check setup logs ({}) for more details.'.format(SETUP_LOGS_PATH))
        exit(0)
