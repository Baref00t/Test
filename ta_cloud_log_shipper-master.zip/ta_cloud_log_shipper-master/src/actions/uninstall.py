"""Implements the uninstall action"""

import os
import shutil
import logging
import subprocess

from ..helpers import (
    clear,
    get_input,
    is_installed,
    iterate_dirs,
    print_and_log,
    print_separator
)
from ..constants import (
    BKP_PATH,
    LOG_LEVEL,
    CONFIG_DIR,
    POSITIVE_BOOLEAN_INPUTS,
    VALID_BOOLEAN_INPUTS,
    SETUP_LOGS_DIR
)
from .action_helpers import (
    get_volumes,
    check_and_stop_containers
)
from ..logger_manager import LoggerManager

logger = LoggerManager('setup', LOG_LEVEL).get_logger()


def remove_images():
    """
    Removes the images from host machine which are configured in docker compose
    """
    try:
        subprocess.Popen(['docker-compose', 'down', '--rmi', 'all', '--remove-orphans'], cwd=CONFIG_DIR).wait()
    except Exception as err:
        print_and_log('An error occurred while removing docker images. Error: {}'.format(err), logging.ERROR)
        return False

    return True


def uninstall():
    """
    Uninstalls Netskope CLS from client's machine

    :returns: True in case of success, False otherwise
    """
    try:
        if not is_installed():
            print_and_log('It seems that Netskope CLS is not installed yet.')
            return False

        if not check_and_stop_containers():
            return False

        clear()
        volumes = set(get_volumes(os.path.join(CONFIG_DIR, 'docker-compose.yml')))
        # os.path.exists() function may return False, if permission is not granted to execute os.stat() on the
        # requested file, even if the path exists.
        print_separator()
        print('Following files will be deleted in the process of uninstallation:')
        print_separator()

        print('Configured docker images and corresponding docker containers')
        for volume_path in volumes:
            print('\n'.join(iterate_dirs(volume_path)))
        print('\n'.join(iterate_dirs(BKP_PATH)))
        print('\n'.join(iterate_dirs('.')))
        print('/'.join(os.path.dirname(os.path.realpath(__file__)).split('/')[:-2]))
        print_separator()

        inp = get_input('Are you sure you want to proceed with uninstallation? (y/n): ')
        while inp not in VALID_BOOLEAN_INPUTS:
            inp = get_input('Invalid choice. Try again (y/n): ')

        inp = inp in POSITIVE_BOOLEAN_INPUTS

        if not inp:
            return False

        inp = get_input('\nIf you want to uninstall, type \'DELETE\', otherwise type \'exit\': ')
        while not (inp == 'delete' or inp == 'exit'):
            inp = get_input('Invalid input. Try again (DELETE/exit): ')

        logger.info('Choice of uninstall "{}"'.format(inp))
        inp = inp == 'delete'

        if not inp:
            return False

        # Delete all the docker images which are configured in docker compose.
        # Assuming single installation per machine. Otherwise this may lead to inconsistencies.
        if not remove_images():
            return False

        # Append deleted files to a list for display purpose
        deleted_files = []
        for volume_path in volumes:
            deleted_files += iterate_dirs(volume_path)
            for dir in os.listdir(volume_path):
                if dir != SETUP_LOGS_DIR:
                    if os.path.isdir(os.path.join(volume_path, dir)):
                        shutil.rmtree(os.path.join(volume_path, dir), ignore_errors=True)
                    else:
                        os.remove(os.path.join(volume_path, dir))

        deleted_files += iterate_dirs(BKP_PATH)
        shutil.rmtree(BKP_PATH, ignore_errors=True)

        deleted_files += iterate_dirs('.')
        deleted_files += [os.path.dirname(os.path.realpath(__file__))]
        shutil.rmtree('/'.join(os.path.dirname(os.path.realpath(__file__)).split('/')[:-2]), ignore_errors=True)

        logger.info('Following are the deleted files in order to uninstall Netskope CLS:')
        logger.info('\n' + '\n'.join(deleted_files))

    except Exception as err:
        print('An error occurred while uninstalling the application. Error: {}'.format(err))
        return False
    else:
        print_separator()
        print_and_log('Netskope CLS uninstalled successfully.')
        print_separator()

    return True
