"""Constants for CLI"""

import os
import logging

# Logging
LOG_LEVEL = logging.INFO
MAX_BYTES_PER_LOG_FILE = 10485760
LOG_BACKUP_COUNT = 10
LOG_BASE_DIR = os.path.join('/', 'var', 'log', 'netskope_cls')
PLUGIN_MCAS = 'mcas'
# General
BKP_PATH = os.path.join('/', 'etc', 'cls-bkp')
WIDTH = 90
VERSION = '2.0.0'
ENV_TEMPLATE = {}
CONFIG_VOLUME = '/etc/configs/'
CONFIG_DIR = 'netskope-cls-config'
VALID_BOOLEAN_INPUTS = ['y', 'n', 'yes', 'no']
POSITIVE_BOOLEAN_INPUTS = ['y', 'yes']
NEGATIVE_BOOLEAN_INPUTS = ['n', 'no']
PLUGINS = ['CSCC', 'SYSLOG', 'AZURE_SENTINEL', 'MCAS']
API_URL = "https://{}.goskope.com/api/v1/alerts"
SETUP_MODES = {
    'INSTALL': 1,
    'REPAIR': 2,
    'UPGRADE': 3,
    'UNINSTALL': 9
}
MCAS_EVENT_TYPES = ['page', 'application']
TEMPLATE_DIR = os.path.join('static', 'templates')
STATIC_DIR = 'static'
TEMPLATE_ENV_DIR = os.path.join(STATIC_DIR, 'templates', 'env')
TEMPLATE_DOCKER_COMPOSE_PATH = os.path.join(STATIC_DIR, 'templates', 'docker-compose.yml')
FIELD_EXCLUDED_FROM_LOGS = ['API_KEY', 'PROXY_PORT', 'PROXY_SERVER', 'USERNAME', 'PASSWORD']
SETUP_LOGS_PATH = '/var/log/netskope_cls/setup_logs/setup.log'
SETUP_LOGS_DIR = 'setup_logs'

# Display purpose
AVAILABLE_VALS = {
    'PLUGIN_TYPE': ['SYSLOG', 'CSCC', 'AZURE_SENTINEL', 'MCAS'],
    'ALERT_TYPE': ['anomaly', 'DLP', 'malware', 'policy', 'Compromised Credential', 'Legal Hold', 'Malsite',
                   'Quarantine', 'Remediation', 'Security Assessment', 'Watchlist', 'all'],
    'EVENT_TYPE': ['application', 'audit', 'infrastructure', 'page', 'network', 'all'],
    'LOG_LEVEL': ['WARNING', 'INFO', 'DEBUG', 'ERROR'],
    'TIME_PERIOD': [3600, 86400, 604800, 2592000, 7776000],
    'SYSLOG_FORMAT': ['CEF'],
    'SYSLOG_PROTOCOL': ['UDP', 'TCP', 'TLS'],
    'PROXY_SCHEME': ['HTTPS', 'HTTP']
}

TOOLTIPS = {
    'API_KEY': 'It shows encrypted value if the value already exists and the new value will be encrypted once saved.',
    'TENANT_NAME': 'Name of tenant excluding ".goskope.com". If the tenant is only reachable via proxy, make sure '
                   'that the proxy is configured.',
    'N_THREADS': 'Number of thread(s) for data ingestion (max: 16).',
    'SYSLOG_SERVER': 'IP Address/FQDN of syslog server.',
    'SYSLOG_MAP': 'Enter the path for the Syslog mapping file. Based on this path, the file will be copied to the '
                  'default location.',
    'SYSLOG_CERT_FILE': 'Name of the certificate file.',
    'ORGANIZATION_ID': 'Organization id of GCP.',
    'CSCC_MAP': 'Enter the path for the CSCC mapping file. Based on this path, the file will be copied to the default '
                'location.',
    'POLL_INTERVAL': 'Interval between each poll in seconds.',
    'TIME_PERIOD': 'Enter time period in seconds(1 hour = 3600, 1 day = 86400, 7 days = 604800, 30 days = 2592000, '
                   '90 days = 7776000).',
    'POLL_OFFSET': 'This time (in seconds) will be subtracted from the current time to ensure that Netskope has '
                   'published all logs before the pull request. This is used to prevent data loss.',
    'ENABLE_PROXY': 'Enter yes/no to enable/disable the proxy.',
    'PROXY_SCHEME': 'Enter scheme for proxy.',
    'PROXY_SERVER': 'IP Address/FQDN for proxy server.',
    'PROXY_PORT': 'Enter port value for proxy.',
    'ENABLE_DEDUPLICATION': 'Enter yes/no to enable/disable data deduplication. If enabled, data ingestion would be '
                            'sequential.',
    'AUTHENTICATED_PROXY': 'Enter yes/no to enable/disable authenticated proxy.',
    'USERNAME': 'Enter username for authentication.',
    'PASSWORD': 'Enter password for authentication. It shows encrypted value if the value already exists and the new value will be encrypted once saved.',
    'WORKSPACE_ID': 'ID of Azure Sentinel Workspace.',
    'PRIMARY_KEY': 'Primary key for authentication with Azure Sentinel. It shows encrypted value if the value already exists and the new value will be encrypted once saved.',
    'AZURE_SENTINEL_MAP': 'Enter the path for the Azure Sentinel mapping file. Based on this path, the file will be '
                          'copied to the default location.',
    'ALERTS_LOG_TYPE_NAME': 'Log type name for Netskope Alerts. It should consist of alphanumerics and underscores '
                            'only. Based on this name, schema for alerts will be created in Log Analytics Workspace '
                            'with suffix "_CL".',
    'EVENTS_LOG_TYPE_NAME': 'Log type name for Netskope Events. It should consist of alphanumerics and underscores '
                            'only. Based on this name, schema for events will be created in Log Analytics Workspace '
                            'with suffix "_CL".',
    'PORTAL_URL': 'MCAS portal URL.',
    'API_TOKEN': 'API token for authentication with MCAS portal. It shows encrypted value if the value already exists and the new value will be encrypted once saved.',
    'DATA_SOURCE': 'Name of the data source in which the data is to be ingested. It must be created on MCAS portal before data ingestion.',
    'MCAS_MAP': 'Enter the path for the MCAS mapping file. Based on the path, the file will be '
                'copied to the default location.'
}

AES_KEY = 'Netskope Cloud Log Shipper'  # AES key for encryption
DOCKER_COMPOSE_SECURE_ATTRIBUTES = ['API_KEY']
ENV_SECURE_ATTRIBUTES = ['PRIMARY_KEY', 'PASSWORD', 'API_TOKEN']
