import base64
import hashlib
from Crypto import Random
from Crypto.Cipher import AES


class AESCipher:
    """ Implements AES encryption """

    def __init__(self, key):
        """Constructor"""
        self.bs = AES.block_size  # AES block size (16)

        # Convert any key to 32 byte hash in order to apply AES-256
        self.key = hashlib.sha256(key.encode()).digest()  # NOSONAR

    def encrypt(self, raw):
        """
        Encrypts the given plain text string

        :param raw: Plain text to be encrypted
        :returns: Encrypted text
        """
        raw = self._pad(raw)
        iv = Random.new().read(AES.block_size)
        cipher = AES.new(self.key, AES.MODE_CBC, iv)  # NOSONAR
        return base64.b64encode(iv + cipher.encrypt(raw.encode())).decode('utf-8')

    def decrypt(self, enc):
        """
        Decrypts the given encrypted text string

        :param enc: Encrypted text to be decrypted
        :returns: Decrypted text
        """
        enc = base64.b64decode(enc)
        iv = enc[:AES.block_size]
        cipher = AES.new(self.key, AES.MODE_CBC, iv)  # NOSONAR
        return self._unpad(cipher.decrypt(enc[AES.block_size:])).decode('utf-8')

    @staticmethod
    def _unpad(s):
        """
        Unpads the given string

        :param s: String to be unpadded
        :returns: Unpadded string
        """
        return s[:-ord(s[len(s) - 1:])]

    def _pad(self, s):
        """
        Pads the given string in order to make its lenght in multiple of 16 (AES block size)

        :param s: String to be padded
        :returns: Padded string
        """
        return s + (self.bs - len(s) % self.bs) * chr(self.bs - len(s) % self.bs)
